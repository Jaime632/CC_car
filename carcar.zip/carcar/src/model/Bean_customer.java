package model;
import java.util.*;


public class Bean_customer {
    public static Bean_customer currentLoginUser = null;
    
    private String customer_id;
    private String sex;
    private String passWord;
    private String phone_number;
    private String mailbox;
    private String city;
    private java.sql.Time regtime;
    
    
    public String getCustomer_id() {
        return customer_id;
    }
    public void setCustomer_id(String customer_id) {
        this.customer_id = customer_id;
    }
    
    
    public String getSex() {
        return sex;
    }
    public void setSex(String sex) {
        this.sex= sex;
    }
    
    
    public String getPassWord() {
        return passWord;
    }
    public void setPassWord(String passWord) {
        this.passWord = passWord;
    }
    
    
    public String getPhone_number() {
        return phone_number;
    }
    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }
    
    public String getMailbox() {
        return mailbox;
    }
    public void setMailbox(String mailbox) {
        this.mailbox = mailbox;
    }

    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    
    public java.sql.Time getRegtime() {
        return regtime;
    }
    public void setRegtime(java.sql.Time regtime) {
        this.regtime = regtime;
    }



    

    
}
