package model;

import javax.print.DocFlavor;
import java.io.StringReader;

public class Bean_car_info {
    public static final String[] tableTitles = {"牌照号码","所属车型","当前状态"};

    
    private int car_id;
    private String model_name;
    private String web_name;
    private int scrap_id;
    private String plate_num;
    private String car_model;
    private String staus;
    private int price_day;
    private int all_time;

    private String len_web;
    private String ren_web;

    private String customer_id;
  
     public int getCar_id() {
        return car_id;
    }
    public void setCar_id(int car_id) {
        this.car_id = car_id;
    }

    public String getModel_name() {
        return model_name;
    }
    public void setModel_name(String model_name) {
        this.model_name = model_name;
    }

    public String getWeb_name() {
        return web_name;
    }
    public void setWeb_name(String web_name) {
        this.web_name = web_name;
    }

    public int getScrap_id() {
        return scrap_id;
    }
    public void setScrap_id(int scrap_id) {
        this.scrap_id = scrap_id;
    }
    
    public String getPlate_num() {
        return plate_num;
    }
    public void setPlate_num(String plate_num) {
        this.plate_num = plate_num;
    }

    public String getCar_model() {
        return car_model;
    }
    public void setCar_model(String car_model) {
        this.car_model = car_model;
    }
    public String getStaus() {
        return staus;
    }
    public void setStaus(String staus) {
        this.staus = staus;
    }

    public int getPrice_day() {
        return price_day;
    }
    public void setPrice_day(int price_day) {
        this.price_day = price_day;
    }

    public String getCustomer_id()
    {
        return customer_id;
    }
    public void setCustomer_id(String customer_id)
    {
        this.customer_id = customer_id;
    }

    public int getAll_time()
    {
        return all_time;
    }
    public void setAll_time(int all_time)
    {
        this.all_time = all_time;
    }
    public String getLen_web()
    {
        return len_web;
    }
    public void setLen_web(String len_web)
    {
        this.len_web = len_web;
    }

    public String getRen_web()
    {
        return ren_web;
    }
    public void setRen_web(String ren_web)
    {
        this.ren_web = ren_web;
    }
    
    public String getCell(int col) {
        if (col == 0) return String.valueOf(this.getPlate_num());
        else if (col == 1) return String.valueOf(this.getCar_model());
        else if (col == 2) return String.valueOf(this.getStaus());
        else return "";
    }


}
