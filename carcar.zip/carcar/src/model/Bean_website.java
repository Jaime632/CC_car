package model;

import java.sql.Date;

public class Bean_website {
    public static final String[] tableTitles = {"网点名称", "所属城市", "地址", "联系电话"};

    
    private int web_id;
    private String web_name;
    private String city;
    private String address;
    private String phone_num;
    
    public int getWeb_id() {
        return web_id;
    }
    public void setWeb_id(int web_id) {
        this.web_id = web_id;
    }

    public String getWeb_name() {
        return web_name;
    }
    public void setWeb_name(String web_name) {
        this.web_name = web_name;
    }


    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }


    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }

    
    public String getPhone_num() {
        return phone_num;
    }

    public void setPhone_num(String phone_num) {
        this.phone_num = phone_num;
    }


    public String getCell(int col) {
        if (col == 0) return String.valueOf(this.getWeb_name());
        else if (col == 1) return this.getCity();
        else if (col == 2) return String.valueOf(this.getAddress());
        else if (col == 3) return String.valueOf(this.getPhone_num());
        else return "";
    }

}
