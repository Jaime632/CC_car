package model;


import java.sql.Date;

public class Bean_car_manage {
    public static final String[] tableTitles = {"调出网点编号", "调入网点编号", "车辆编号", "调拨时间"};

    
    private int manage_id;

    private String car_plate;
    private java.sql.Date manage_time;
    private String len_web_name;
    private String  ren_web_name;
    
    
    public int getManage_id() {
        return manage_id;
    }
    public void setManage_id(int manage_id) {
        this.manage_id = manage_id;
    }
    public String getCar_plate() {
        return car_plate;
    }
    public void setCar_plate(String car_plate) {
        this.car_plate = car_plate;
    }
    public java.sql.Date getManage_time() {
        return manage_time;
    }
    public void setManage_time(java.sql.Date manage_time) {
        this.manage_time = manage_time;
    }
    public String getRen_web_name() {
        return ren_web_name;
    }
    public void setRen_web_name(String ren_web_name) {
        this.ren_web_name = ren_web_name;
    }
    public String getLen_web_name() {
        return len_web_name;
    }
    public void setLen_web_name(String len_web_name) {
        this.len_web_name = len_web_name;
    }
    
    
    
//
//    public String getCell(int col) {
//        if (col == 0) return String.valueOf(this.getOut_web_id());
//        else if (col == 1) return String.valueOf(this.getIn_web_id());
//        else if (col == 2) return String.valueOf(this.getCar_id());
//        else if (col == 3) return String.valueOf(this.getManage_time());
//        else return "";
//    }

}
