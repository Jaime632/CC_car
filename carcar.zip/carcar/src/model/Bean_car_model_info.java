package model;
import java.util.*;

import java.sql.Date;

public class Bean_car_model_info {
    public static final String[] tableTitles = {"车型名称","品牌","排量","排挡","座位数","价格","图片"};

    
    private int model_id;
    private int type_id;
    private String model_name;
    private String brand;
    private String displacement;
    private String gear;
    private String seat_number;
    private Double price ;

    
     public int getModel_id() {
        return model_id;
    }
    public void setModel_id(int model_id) {
        this.model_id = model_id;
    }
    public int getType_id() {
        return type_id;
    }
    public void setType_id(int type_id) {
        this.type_id = type_id;
    }
    
    public String getModel_name() {
        return model_name;
    }
    public void setModel_name(String model_name) {
        this.model_name = model_name;
    }

    public String getBrand() {
        return brand;
    }
    public void setBrand(String brand) {
        this.brand = brand;
    }
    public String getDisplacement() {
        return displacement;
    }
    public void setDisplacement(String displacement) {
        this.displacement = displacement;
    }
    public String getGear() {
        return gear;
    }
    public void setGear(String gear) {
        this.gear = gear;
    }
    public String getSeat_number() {
        return seat_number;
    }
    public void setSeat_number(String seat_number) {
        this.seat_number = seat_number;
    }
    public Double getPrice() {
        return price;
    }
    public void setPrice(Double price) {
        this.price = price;
    }

    
    public String getCell(int col) {
        if (col == 0) return String.valueOf(this.getModel_name());
        else if (col == 1) return String.valueOf(this.getBrand());
        else if (col ==2) return String.valueOf(this.getDisplacement());
        else if (col ==3) return String.valueOf(this.getGear());
        else if (col ==4) return String.valueOf(this.getSeat_number());
        else if (col ==5) return String.valueOf(this.getPrice());

        else return "";
    }

}
