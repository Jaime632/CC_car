package model;
import java.util.*;


public class Bean_woker_admin {
    public static Bean_woker_admin currentLoginUser = null;
    
    private String passWord;
    private String wo_id;
    private String web_id;

    public String getPassWord() {
        return passWord;
    }
    public void setPassWord(String passWord) {
        this.passWord = passWord;
    }

    
    public String getWo_id() {
        return wo_id;
    }
    public void setWo_id(String wo_id) {
        this.wo_id = wo_id;
    }

    public String getWeb_id() {
        return web_id;
    }
    public void setWeb_id(String web_id) {
        this.web_id = web_id;
    }

    
}
