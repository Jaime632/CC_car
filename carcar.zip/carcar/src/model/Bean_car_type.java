package model;
import java.sql.Date;

public class Bean_car_type {
    public static final String[] tableTitles = {"车辆类别名称","车辆类别简介"};
    
    private int type_id;
    private String type_name;
    private String type_des;

  
    public int getType_id() {
        return type_id;
    }
    public void setType_id(int stype_id) {
        this.type_id = type_id;
    }
    
    public String getType_name() {
        return type_name;
    }
    public void setType_name(String type_name) {
        this.type_name = type_name;
    }

    
    public String getType_des() {
        return type_des;
    }


    public void setType_des(String type_des) {
        this.type_des = type_des;
    }


    
    public String getCell(int col) {
        if (col == 0) return String.valueOf(this.getType_name());
        else if (col == 1) return String.valueOf(this.getType_des());
        else return "";
    }

}
