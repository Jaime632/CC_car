package model;


import java.sql.Date;

public class Bean_car_scrap {
    public static final String[] tableTitles = {"操作员", "报废说明", "报废时间"};

    
    private int scrap_id;
    private String woker_id;
    private String scrap_remark;
    private java.sql.Date scrap_time;

    
     public int getScrap_id() {
        return scrap_id;
    }
    public void setScrap_id(int scrap_id) {
        this.scrap_id = scrap_id;
    }

    
    public String getWoker_id() {
        return woker_id;
    }
    public void setWoker_id(String woker_id) {
        this.woker_id = woker_id;
    }

    
    public String getScrap_remark() {
        return scrap_remark;
    }
    public void setScrap_remark(String scrap_remark) {
        this.scrap_remark = scrap_remark;
    }


    public Date getScrap_time() {
        return scrap_time;
    }
    public void setScrap_time(java.sql.Date scrap_time) {
        this.scrap_time = scrap_time;
    }


    public String getCell(int col) {
        if (col == 0) return String.valueOf(this.getWoker_id());
        else if (col == 1) return String.valueOf(this.getScrap_remark());
        else if (col == 2) return String.valueOf(this.getScrap_time());
        else return "";
    }

}
