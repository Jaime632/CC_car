package model;


import javax.print.DocFlavor;
import java.sql.Date;

public class Bean_car_ord {
    public static final String[] tableTitles = {"提车时间", "还车时间", "租车时长", "初始金额", "结算金额", "订单状态", "租车网点", "还车网点"};

    
    private int ord_id;
    private String customer_id;
    private String car_plate;
    private java.sql.Date in_time;
    private java.sql.Date out_time;
    private int all_time;
    private int spend_money;

    private String status;
    private String len_web;
    private String ren_web;
    private int price_day;
    
     public int getOrd_id() {
        return ord_id;
    }
    public void setOrd_id(int ord_id) {
        this.ord_id = ord_id;
    }
    public String getCustomer_id() {
        return customer_id;
    }
    public void setCustomer_id(String customer_id) {
        this.customer_id = customer_id;
    }
    public String getCar_plate() {
        return car_plate;
    }
    public void setCar_plate(String car_plate) {
        this.car_plate = car_plate;
    }
    public Date getIn_time() {
        return in_time;
    }
    public void setIn_time(java.sql.Date in_time) {
        this.in_time = in_time;
    }
    public Date getOut_time() {
        return out_time;
    }
    public void setOut_time(java.sql.Date out_time) {
        this.out_time = out_time;
    }
    public int getAll_time() {
        return all_time;
    }
    public void setAll_time(int all_time) {
        this.all_time = all_time;
    }


    public int getSpend_money() {
        return spend_money;
    }
    public void setSpend_money(int spend_money) {
        this.spend_money = spend_money;
    }
    
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    
    public String getLen_web() {
        return len_web;
    }
    public void setLen_web(String len_web) {
        this.len_web = len_web;
    }
    public String getRen_web() {
        return ren_web;
    }
    public void setRen_web(String ren_web) {
        this.ren_web = ren_web;
    }


    public int getPrice_day(){
        return price_day;
    }
    public void setPrice_day(int price_day){
         this.price_day = price_day;
    }

//    public Bean_car_ord get(int i) {
//    }

//    public String getCell(int col) {
//        if (col == 0) return String.valueOf(this.getIn_time());
//        else if (col == 1) return String.valueOf(this.getOut_time());
//        else if (col == 2) return String.valueOf(this.getAll_time());
//        else if (col == 3) return String.valueOf(this.getStatus());
//        else if (col == 6) return String.valueOf(this.getLen_web());
//        else if (col == 7) return String.valueOf(this.getRen_web());
//
//        else return "";
//    }

}
