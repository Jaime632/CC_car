package ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import control.CarType;
import control.UserManager;
import model.Bean_car_type;
import util.BaseException;

public class FrmModifyCarType extends JDialog implements ActionListener {
    private Bean_car_type type=null;
    private JPanel toolBar = new JPanel();
    private JPanel workPane = new JPanel();
    private JButton btnOk = new JButton("确定");
    private JButton btnCancel = new JButton("取消");
    private final JLabel lblDescrb = new JLabel("描述：");
    private final JTextField edtDescrb = new JTextField();

    public FrmModifyCarType(JDialog f, String s, boolean b, Bean_car_type type) {
        super(f, s, b);
        edtDescrb.setBounds(78, 68, 126, 40);
        this.edtDescrb.setText(type.getType_des());
        edtDescrb.setColumns(10);
        this.type=type;
        toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
        toolBar.add(btnOk);
        toolBar.add(btnCancel);
        this.getContentPane().add(toolBar, BorderLayout.SOUTH);

        this.getContentPane().add(workPane, BorderLayout.CENTER);
        workPane.setLayout(null);
        lblDescrb.setBounds(24, 71, 44, 15);
        workPane.add(lblDescrb);
        workPane.add(edtDescrb);
        this.setSize(300, 244);
        // 屏幕居中显示
        double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
        double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
        this.setLocation((int) (width - this.getWidth()) / 2,
                (int) (height - this.getHeight()) / 2);

        this.validate();
        this.btnOk.addActionListener(this);
        this.btnCancel.addActionListener(this);
        this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                FrmModifyCarType.this.type=null;
            }
        });
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==this.btnCancel) {
            this.setVisible(false);
            this.type=null;
            return;
        }
        else if(e.getSource()==this.btnOk){
            type.setType_des(this.edtDescrb.getText());
            try {
                (new CarType()).modifyCarType(type);
                this.setVisible(false);
            } catch (BaseException e1) {
                JOptionPane.showMessageDialog(null, e1.getMessage(),"错误",JOptionPane.ERROR_MESSAGE);
            }
        }

    }
    public Bean_car_type getCarType() {
        return type;
    }

}
