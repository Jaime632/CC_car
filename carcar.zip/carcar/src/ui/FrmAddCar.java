package ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import control.Car;
import control.CarModel;
import control.CarType;
import control.WebManager;
import model.Bean_car_info;
import model.Bean_car_model_info;
import model.Bean_car_type;
import model.Bean_website;
import util.BaseException;
import javax.swing.DefaultComboBoxModel;

public class FrmAddCar extends JDialog implements ActionListener {
    private Bean_car_info car=null;

    private JPanel toolBar = new JPanel();
    private JPanel workPane = new JPanel();
    private JButton btnOk = new JButton("确定");
    private JButton btnCancel = new JButton("取消");
    private JLabel labelPlate = new JLabel("车牌号：");
    private JLabel labelPrice_day = new JLabel("日租金：");


    private JTextField edtPrice_day = new JTextField(20);

    private JTextField edtPlate = new JTextField(20);

    private JComboBox cmbModel;
    private JComboBox cmbModel2;
    private JComboBox cmbWebSite;
    private JComboBox cmbSts;

    private Map<Integer,Bean_car_model_info> carModelMap_id=new HashMap<Integer,Bean_car_model_info>();
    private Map<String,Bean_car_model_info> carModelMap_name=new HashMap<String,Bean_car_model_info>();

    private Map<Integer,Bean_website> carWebSiteMap_id=new HashMap<Integer,Bean_website>();
    private Map<String,Bean_website> carWebSiteMap_name=new HashMap<String,Bean_website>();

    private Map<Integer,Bean_car_type> carType_id=new HashMap<Integer,Bean_car_type>();
    private Map<String,Bean_car_type> carType_name=new HashMap<String,Bean_car_type>();

    public FrmAddCar(JDialog f, String s, boolean b) {
        super(f, s, b);
        toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
        toolBar.add(btnOk);
        toolBar.add(btnCancel);
        this.getContentPane().add(toolBar, BorderLayout.SOUTH);
        this.getContentPane().add(workPane, BorderLayout.WEST);
        workPane.setLayout(null);
        labelPlate.setBounds(10, 10, 77, 15);
        workPane.add(labelPlate);
        edtPlate.setBounds(116, 10, 126, 21);
        workPane.add(edtPlate);

        labelPrice_day.setBounds(10, 160, 77, 15);
        workPane.add(labelPrice_day);
        edtPrice_day.setBounds(116, 160, 126, 21);
        workPane.add(edtPrice_day);



        this.getContentPane().add(workPane, BorderLayout.CENTER);

        JLabel lblModel2 = new JLabel("车类名称：");
        lblModel2.setBounds(10, 130, 77, 15);
        workPane.add(lblModel2);

        JLabel lblModel = new JLabel("车型名称：");
        lblModel.setBounds(10, 40, 77, 15);
        workPane.add(lblModel);


        JLabel lblWebSite = new JLabel("网点名称：");
        lblWebSite.setBounds(10, 70, 77, 15);
        workPane.add(lblWebSite);



        JLabel lblSts = new JLabel("车辆状态：");
        lblSts.setBounds(10, 100, 77, 15);
        workPane.add(lblSts);



        cmbSts = new JComboBox(new Object[]{});
        cmbSts.setModel(new DefaultComboBoxModel(new String[] {"", "未租赁", "已租赁", "修理中"}));
        cmbSts.setBounds(116, 100, 126, 21);
        workPane.add(cmbSts);

        //提取车类信息
        List<Bean_car_model_info> models=null;
        List<Bean_website> webs=null;
        List<Bean_car_type> models2 = null;
        try {
            models = (new CarModel()).loadAllCarModel();
            String[] strModels=new String[models.size()+1];
            strModels[0]="";
            for(int i=0;i<models.size();i++) {
                carModelMap_name.put(models.get(i).getModel_name(),models.get(i));
                carModelMap_id.put(models.get(i).getModel_id(), models.get(i));
                strModels[i+1]=models.get(i).getModel_name();
            }
            cmbModel=new JComboBox(strModels);
            cmbModel.setBounds(116, 40, 126, 21);
            workPane.add(cmbModel);


            webs = (new WebManager()).loadAllWebSite();
            String[] strWebs=new String[webs.size()+1];
            strWebs[0]="";
            for(int i=0; i<webs.size(); i++) {
                carWebSiteMap_name.put(webs.get(i).getWeb_name(), webs.get(i));
                carWebSiteMap_id.put(webs.get(i).getWeb_id(), webs.get(i));
                strWebs[i+1]=webs.get(i).getWeb_name();
            }
            cmbWebSite = new JComboBox(strWebs);
            cmbWebSite.setBounds(116, 70, 126, 21);
            workPane.add(cmbWebSite);

            models2 = (new CarType()).loadAllCarType();
            String[] strModels2 = new String[models2.size()+1];
            strModels2[0]="";
            for(int i=0;i<models2.size();i++){
                carType_name.put(models2.get(i).getType_name(), models2.get(i));
                carType_id.put(models2.get(i).getType_id(), models2.get(i));
                strModels2[i+1]=models2.get(i).getType_name();
            }
            cmbModel2=new JComboBox(strModels2);
            cmbModel2.setBounds(116,130,126,21);
            workPane.add(cmbModel2);



        } catch (BaseException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }

        this.setSize(300, 300);
        // 屏幕居中显示
        double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
        double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
        this.setLocation((int) (width - this.getWidth()) / 2,
                (int) (height - this.getHeight()) / 2);

        this.validate();
        this.btnOk.addActionListener(this);
        this.btnCancel.addActionListener(this);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==this.btnCancel) {
            this.setVisible(false);
            return;
        }
        else if(e.getSource()==this.btnOk){

            if(this.cmbModel.getSelectedIndex()<0){
                JOptionPane.showMessageDialog(null,  "请选择车型","提示",JOptionPane.ERROR_MESSAGE);
                return;
            }
            else if(this.cmbWebSite.getSelectedIndex()<0){
                JOptionPane.showMessageDialog(null,  "请选择网点","提示",JOptionPane.ERROR_MESSAGE);
                return;
            }
            else if(this.cmbSts.getSelectedIndex()<0){
                JOptionPane.showMessageDialog(null,  "请选择状态","提示",JOptionPane.ERROR_MESSAGE);
                return;
            }



            String Sts=this.cmbSts.getSelectedItem().toString();
            Bean_car_model_info cm = this.carModelMap_name.get(this.cmbModel.getSelectedItem().toString());
            Bean_website ws = this.carWebSiteMap_name.get(this.cmbWebSite.getSelectedItem().toString());
            Bean_car_type ct = this.carType_name.get(this.cmbModel2.getSelectedItem().toString());
            try {

                if(cm==null) throw new BaseException("请选择车型");
                if(ws==null) throw new BaseException("请选择网点");
                if(ct==null) throw new BaseException("请选择车类");
                if(Sts == null || "".equals(Sts)) throw new BaseException("请选择状态");
            }catch(BaseException e1) {
                JOptionPane.showMessageDialog(null, e1.getMessage(),"错误",JOptionPane.ERROR_MESSAGE);
                return;
            }

            car=new Bean_car_info();
            car.setPlate_num(this.edtPlate.getText().toString());
            car.setCar_model(cm.getModel_name());
            car.setWeb_name(ws.getWeb_name());
            car.setModel_name(ct.getType_name());
            car.setStaus(Sts);
            car.setPrice_day(Integer.valueOf(this.edtPrice_day.getText()));
            try {
                (new Car()).createCar(car);
                this.setVisible(false);
            } catch (BaseException e2) {
                this.car=null;
                JOptionPane.showMessageDialog(null, e2.getMessage(),"错误",JOptionPane.ERROR_MESSAGE);
            }
        }

    }
    public Bean_car_info getCar() {
        return car;
    }
}