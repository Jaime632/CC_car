package ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import control.CarLend;
import control.CarType;
import model.Bean_car_info;
import model.Bean_car_type;
import model.Bean_website;
import util.BaseException;

public class FrmLendCarTime extends JDialog implements ActionListener {
    private final Bean_car_info bs;
    private Bean_car_info type=null;

    private JPanel toolBar = new JPanel();
    private JPanel workPane = new JPanel();
    private JButton btnOk = new JButton("确定");
    private JButton btnCancel = new JButton("取消");

    private JLabel labelTypeName = new JLabel("租车用户名：");

    private JLabel labelDescrb = new JLabel("还车日期：");

    private JComboBox cmbSts;


    private JTextField edtTypeName = new JTextField(20);
//    private JTextField edtDescrb = new JTextField(20);

    public FrmLendCarTime(JDialog f, String s, boolean b, Bean_car_info bs) {
        super(f, s, b);

        toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
        toolBar.add(btnOk);
        toolBar.add(btnCancel);
        this.bs=bs;
        this.getContentPane().add(toolBar, BorderLayout.SOUTH);
        this.getContentPane().add(workPane, BorderLayout.WEST);
        workPane.setLayout(null);
        labelTypeName.setBounds(10, 42, 77, 15);
        workPane.add(labelTypeName);
        edtTypeName.setBounds(116, 39, 126, 21);
        workPane.add(edtTypeName);
        labelDescrb.setBounds(10, 67, 77, 15);
        workPane.add(labelDescrb);
//        edtDescrb.setBounds(116, 64, 126, 71);
//        workPane.add(edtDescrb);


        cmbSts = new JComboBox(new Object[]{});
        cmbSts.setModel(new DefaultComboBoxModel(new String[] {"2021-9-14", "2021-9-15","2021-9-16","2021-9-17","2021-9-18","2021-9-19","2021-9-20","2021-9-21","2021-9-22","2021-9-23","2021-9-24","2021-9-25","2021-9-26","2021-9-27","2021-9-28","2021-9-29","2021-9-30","2021-10-1","2021-10-2","2021-10-3"}));
        cmbSts.setBounds(116, 100, 126, 21);
        workPane.add(cmbSts);

        this.getContentPane().add(workPane, BorderLayout.CENTER);
        this.setSize(300, 236);
        // 屏幕居中显示
        double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
        double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
        this.setLocation((int) (width - this.getWidth()) / 2,
                (int) (height - this.getHeight()) / 2);

        this.validate();
        this.btnOk.addActionListener(this);
        this.btnCancel.addActionListener(this);

    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==this.btnCancel) {
            this.setVisible(false);
            return;
        }

        else if(e.getSource()==this.btnOk){

            String typeName=this.edtTypeName.getText();
//            String typeDescrb=this.edtDescrb.getText();

            type=new Bean_car_info();
            type.setCustomer_id(typeName);;
//            type.setAll_time(Integer.valueOf(typeDescrb));
            type.setPlate_num(bs.getPlate_num());
            type.setLen_web(bs.getWeb_name());
            type.setPrice_day(bs.getPrice_day());

            try {
                (new CarLend()).LendCar(type);
                this.setVisible(false);

            } catch (BaseException e2) {
                this.type=null;
                JOptionPane.showMessageDialog(null, e2.getMessage(),"错误",JOptionPane.ERROR_MESSAGE);
            }
        }

    }
    public Bean_car_info getCarType() {
        return type;
    }
}
