package ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import control.Car;
import control.CarModel;
import control.CarType;
import control.WebManager;
import model.*;
import util.BaseException;

public class FrmCarManage extends JDialog implements ActionListener {

    private JPanel toolBar = new JPanel();
//    private JButton btnAdd = new JButton("归还车辆");

    private Object tblTitle[]={"车辆调拨编号","调拨车辆车牌号","调拨时间","租车网点","还车网点"};
    private Object tblData[][];
    DefaultTableModel tablmod=new DefaultTableModel();
    private JTable carTable=new JTable(tablmod);

    private List<Bean_car_manage> cars;
    private void reloadCarTable(){
        try {
            cars =(new Car()).loadAllCarManage();
            tblData =new Object[cars.size()][5];
            for(int i=0;i<cars.size();i++){
                tblData[i][0]=cars.get(i).getManage_id();
                tblData[i][1]=cars.get(i).getCar_plate();
                tblData[i][2]=cars.get(i).getManage_time();
                tblData[i][3]=cars.get(i).getLen_web_name();
                tblData[i][4]=cars.get(i).getRen_web_name();

            }
            tablmod.setDataVector(tblData,tblTitle);
            this.carTable.validate();
            this.carTable.repaint();
        } catch (BaseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public FrmCarManage(Frame f, String s, boolean b) {
        super(f, s, b);

        toolBar.setLayout(new FlowLayout(FlowLayout.LEFT));
//        toolBar.add(btnAdd);

        this.getContentPane().add(toolBar, BorderLayout.NORTH);
        //提取现有数据
        this.reloadCarTable();
        this.getContentPane().add(new JScrollPane(this.carTable), BorderLayout.CENTER);

        // 屏幕居中显示
        this.setSize(900, 700);
        double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
        double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
        this.setLocation((int) (width - this.getWidth()) / 2,
                (int) (height - this.getHeight()) / 2);

        this.validate();

//        this.btnAdd.addActionListener(this);
        this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                //System.exit(0);
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub

//        if (e.getSource() == this.btnAdd) {
//            int i=this.carTable.getSelectedRow();
//            Bean_car_ord or = this.cars.get(i);
//            FrmRenCar dlg = new FrmRenCar(this, "归还车辆", true, or);
//            dlg.setVisible(true);
//            if (dlg.getCar() != null) {//刷新表格
//                this.reloadCarTable();
//            }
//        }

    }

}
