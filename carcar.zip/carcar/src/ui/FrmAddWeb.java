package ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import control.WebManager;
import model.Bean_website;
import util.BaseException;
import util.BusinessException;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

public class FrmAddWeb extends JDialog implements ActionListener {
    private Bean_website web=null;

    private JPanel toolBar = new JPanel();
    private JPanel workPane = new JPanel();
    private JButton btnOk = new JButton("确定");
    private JButton btnCancel = new JButton("取消");
    private JLabel labelWebName = new JLabel("网点名称：");
    private JLabel labelCity = new JLabel("所属城市：");

    private JTextField edtWebName = new JTextField(20);
    private JTextField edtWebCity = new JTextField(20);
    private JTextField edtWebAddr;
    private JTextField edtTelNum;

    public FrmAddWeb(JDialog f, String s, boolean b) {
        super(f, s, b);
        toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
        toolBar.add(btnOk);
        toolBar.add(btnCancel);
        this.getContentPane().add(toolBar, BorderLayout.SOUTH);
        this.getContentPane().add(workPane, BorderLayout.WEST);

        JLabel lblAddr = new JLabel("地址：");
        lblAddr.setBounds(10, 92, 60, 15);

        edtWebAddr = new JTextField(20);
        edtWebAddr.setBounds(116, 89, 126, 21);
        edtWebAddr.setColumns(10);

        JLabel lblTelNum = new JLabel("电话号码：");
        lblTelNum.setBounds(10, 119, 77, 15);

        edtTelNum = new JTextField(20);
        edtTelNum.setBounds(116, 116, 126, 21);
        edtTelNum.setColumns(10);
        workPane.setLayout(null);
        labelWebName.setBounds(10, 42, 77, 15);
        workPane.add(labelWebName);
        edtWebName.setBounds(116, 39, 126, 21);
        workPane.add(edtWebName);
        labelCity.setBounds(10, 67, 77, 15);
        workPane.add(labelCity);
        edtWebCity.setBounds(116, 64, 126, 21);
        workPane.add(edtWebCity);
        workPane.add(lblAddr);
        workPane.add(edtWebAddr);
        workPane.add(lblTelNum);
        workPane.add(edtTelNum);
        this.getContentPane().add(workPane, BorderLayout.CENTER);
        this.setSize(300, 236);
        // 屏幕居中显示
        double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
        double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
        this.setLocation((int) (width - this.getWidth()) / 2,
                (int) (height - this.getHeight()) / 2);

        this.validate();
        this.btnOk.addActionListener(this);
        this.btnCancel.addActionListener(this);

    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==this.btnCancel) {
            this.setVisible(false);
            return;
        }
        else if(e.getSource()==this.btnOk){

            String webName=this.edtWebName.getText();
            String webCity=this.edtWebCity.getText();
            String webAddr=this.edtWebAddr.getText();
            String telNum=this.edtTelNum.getText();

            web=new Bean_website();
            web.setWeb_name(webName);
            web.setCity(webCity);
            web.setAddress(webAddr);
            web.setPhone_num(telNum);
            try {
                (new WebManager()).createWeb(web);
                this.setVisible(false);
            } catch (BaseException e2) {
                this.web=null;
                JOptionPane.showMessageDialog(null, e2.getMessage(),"错误",JOptionPane.ERROR_MESSAGE);
            }
        }

    }
    public Bean_website getweb() {
        return web;
    }
}
