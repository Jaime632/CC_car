package ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import control.*;
import model.*;
import util.BaseException;
import javax.swing.DefaultComboBoxModel;

public class FrmRenCar extends JDialog implements ActionListener {
    private Bean_car_ord car=null;

    private JPanel toolBar = new JPanel();
    private JPanel workPane = new JPanel();
    private JButton btnOk = new JButton("确定");
    private JButton btnCancel = new JButton("取消");



    private JComboBox cmbPlate;
    private JComboBox cmbWebSite;
    private JComboBox cmbLend;

    private Map<Integer,Bean_website> carWebSiteMap_id=new HashMap<Integer,Bean_website>();
    private Map<String,Bean_website> carWebSiteMap_name=new HashMap<String,Bean_website>();

    private Map<String,Bean_car_ord> carPlate=new HashMap<String,Bean_car_ord>();

    private Map<String,Bean_car_ord> carLweb=new HashMap<String,Bean_car_ord>();


    public FrmRenCar(JDialog f, String s, boolean b, Bean_car_ord car) {
        super(f, s, b);
        toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
        toolBar.add(btnOk);
        toolBar.add(btnCancel);
        this.getContentPane().add(toolBar, BorderLayout.SOUTH);
        this.getContentPane().add(workPane, BorderLayout.WEST);
        workPane.setLayout(null);

        this.car=car;
        this.getContentPane().add(workPane, BorderLayout.CENTER);


        JLabel lblPlate = new JLabel("归还车辆车牌号：");
        lblPlate.setBounds(10, 40, 87, 15);
        workPane.add(lblPlate);

        JLabel lblWebSite = new JLabel("归还网点名称：");
        lblWebSite.setBounds(10, 70, 87, 15);
        workPane.add(lblWebSite);

        //提取车类信息
        List<Bean_car_ord> models=null;
        List<Bean_website> webs=null;
        List<Bean_car_ord> models2=null;

        try {

            models = (new Car()).loadAllCarOrd();
            String[] strModels=new String[models.size()+1];
            strModels[0]="";
            for(int i=0;i<models.size();i++) {
                carPlate.put(models.get(i).getCar_plate(), models.get(i));
                strModels[i+1]=models.get(i).getCar_plate();
            }
            cmbPlate=new JComboBox(strModels);
            cmbPlate.setBounds(116, 40, 126, 21);
            workPane.add(cmbPlate);


            webs = (new WebManager()).loadAllWebSite();
            String[] strWebs=new String[webs.size()+1];
            strWebs[0]="";
            for(int i=0; i<webs.size(); i++) {
                carWebSiteMap_name.put(webs.get(i).getWeb_name(), webs.get(i));
                carWebSiteMap_id.put(webs.get(i).getWeb_id(), webs.get(i));
                strWebs[i+1]=webs.get(i).getWeb_name();
            }
            cmbWebSite = new JComboBox(strWebs);
            cmbWebSite.setBounds(116, 70, 126, 21);
            workPane.add(cmbWebSite);


            String lenweb = car.getLen_web();

//            models2 = (new Car()).loadAllCarOrd();
//            String[] strModels2=new String[models2.size()+1];
//            strModels2[0]="";
//            for(int i=0;i<models2.size();i++) {
//                carLweb.put(models2.get(i).getLen_web(), models2.get(i));
//                strModels2[i+1]=models2.get(i).getLen_web();
//            }
//            cmbLend =new JComboBox(strModels2);
//            cmbLend.setBounds(116, 100, 126, 21);
//            workPane.add(cmbLend);





        } catch (BaseException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }

        this.setSize(300, 300);
        // 屏幕居中显示
        double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
        double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
        this.setLocation((int) (width - this.getWidth()) / 2,
                (int) (height - this.getHeight()) / 2);

        this.validate();
        this.btnOk.addActionListener(this);
        this.btnCancel.addActionListener(this);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==this.btnCancel) {
            this.setVisible(false);
            return;
        }
        else if(e.getSource()==this.btnOk){

            if(this.cmbPlate.getSelectedIndex()<0){
                JOptionPane.showMessageDialog(null,  "请选择归还车辆车牌","提示",JOptionPane.ERROR_MESSAGE);
                return;
            }
            else if(this.cmbWebSite.getSelectedIndex()<0){
                JOptionPane.showMessageDialog(null,  "请选择归还车辆网点","提示",JOptionPane.ERROR_MESSAGE);
                return;
            }
            String lenweb = car.getLen_web();
            Bean_car_ord or = this.carPlate.get(this.cmbPlate.getSelectedItem().toString());
            Bean_website ws = this.carWebSiteMap_name.get(this.cmbWebSite.getSelectedItem().toString());
//            Bean_car_ord lw = this.carLweb.get(this.cmbLend.getSelectedItem().toString());

            try {

                if(or==null) throw new BaseException("请选择归还车辆车牌");
                if(ws==null) throw new BaseException("请选择归还车辆网点");
            }catch(BaseException e1) {
                JOptionPane.showMessageDialog(null, e1.getMessage(),"错误",JOptionPane.ERROR_MESSAGE);
                return;
            }

            car= new Bean_car_ord();

            car.setCar_plate(or.getCar_plate());
            car.setRen_web(ws.getWeb_name());
            car.setLen_web(lenweb);

            try {
                (new CarLend()).RenCar(car);
                this.setVisible(false);
            } catch (BaseException e2) {
                this.car=null;
                JOptionPane.showMessageDialog(null, e2.getMessage(),"错误",JOptionPane.ERROR_MESSAGE);
            }
        }

    }
    public Bean_car_ord getCar() {
        return car;
    }
}