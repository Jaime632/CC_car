package ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import control.Car;
import control.CarModel;
import control.CarType;
import control.WebManager;
import model.Bean_car_info;
import model.Bean_car_model_info;
import model.Bean_car_type;
import model.Bean_website;
import util.BaseException;
import javax.swing.DefaultComboBoxModel;

public class FrmSelectCar extends JDialog implements ActionListener {
    private Bean_car_info car=null;

    private JPanel toolBar = new JPanel();
    private JPanel workPane = new JPanel();
    private JButton btnOk = new JButton("确定");
    private JButton btnCancel = new JButton("取消");

    private JComboBox cmbWebSite;

    private Map<Integer,Bean_website> carWebSiteMap_id=new HashMap<Integer,Bean_website>();
    private Map<String,Bean_website> carWebSiteMap_name=new HashMap<String,Bean_website>();

    public FrmSelectCar(JDialog f, String s, boolean b) {
        super(f, s, b);
        toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
        toolBar.add(btnOk);
        toolBar.add(btnCancel);
        this.getContentPane().add(toolBar, BorderLayout.SOUTH);
        this.getContentPane().add(workPane, BorderLayout.WEST);
        workPane.setLayout(null);


        this.getContentPane().add(workPane, BorderLayout.CENTER);

//        JLabel lblModel2 = new JLabel("车类名称：");
//        lblModel2.setBounds(10, 130, 77, 15);
//        workPane.add(lblModel2);
//
//        JLabel lblModel = new JLabel("车型名称：");
//        lblModel.setBounds(10, 40, 77, 15);
//        workPane.add(lblModel);
//
//
//        JLabel lblWebSite = new JLabel("网点名称：");
//        lblWebSite.setBounds(10, 70, 77, 15);
//        workPane.add(lblWebSite);
//
//
//
//        JLabel lblSts = new JLabel("车辆状态：");
//        lblSts.setBounds(10, 100, 77, 15);
//        workPane.add(lblSts);



//        cmbSts = new JComboBox(new Object[]{});
//        cmbSts.setModel(new DefaultComboBoxModel(new String[] {"", "未租赁", "已租赁", "修理中"}));
//        cmbSts.setBounds(116, 100, 126, 21);
//        workPane.add(cmbSts);

        //提取车类信息
        List<Bean_website> webs=null;

        try {

            webs = (new WebManager()).loadAllWebSite();
            String[] strWebs=new String[webs.size()+1];
            strWebs[0]="";
            for(int i=0; i<webs.size(); i++) {
                carWebSiteMap_name.put(webs.get(i).getWeb_name(), webs.get(i));
                carWebSiteMap_id.put(webs.get(i).getWeb_id(), webs.get(i));
                strWebs[i+1]=webs.get(i).getWeb_name();
            }
            cmbWebSite = new JComboBox(strWebs);
            cmbWebSite.setBounds(116, 70, 126, 21);
            workPane.add(cmbWebSite);


        } catch (BaseException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }

        this.setSize(300, 300);
        // 屏幕居中显示
        double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
        double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
        this.setLocation((int) (width - this.getWidth()) / 2,
                (int) (height - this.getHeight()) / 2);

        this.validate();
        this.btnOk.addActionListener(this);
        this.btnCancel.addActionListener(this);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==this.btnCancel) {
            this.setVisible(false);
            return;
        }
        else if(e.getSource()==this.btnOk){

            if(this.cmbWebSite.getSelectedIndex()<0){
                JOptionPane.showMessageDialog(null,  "请选择网点","提示",JOptionPane.ERROR_MESSAGE);
                return;
            }


            Bean_website ws = this.carWebSiteMap_name.get(this.cmbWebSite.getSelectedItem().toString());

            try {

                if(ws==null) throw new BaseException("请选择网点");
            }catch(BaseException e1) {
                JOptionPane.showMessageDialog(null, e1.getMessage(),"错误",JOptionPane.ERROR_MESSAGE);
                return;
            }

            car=new Bean_car_info();
            car.setWeb_name(ws.getWeb_name());
            try {

                (new Car()).loadAllCarSelect(car.getWeb_name());
                this.setVisible(false);

                FrmLendCar2 dlg = new FrmLendCar2(this,"租车",true, car.getWeb_name());
                dlg.setVisible(true);

            } catch (BaseException e2) {
                this.car=null;
                JOptionPane.showMessageDialog(null, e2.getMessage(),"错误",JOptionPane.ERROR_MESSAGE);
            }
        }

    }
    public Bean_car_info getCar() {
        return car;
    }
}