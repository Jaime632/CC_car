package ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import control.Car;
import control.CarModel;
import control.CarType;
import control.WebManager;
import model.Bean_car_info;
import model.Bean_car_model_info;
import model.Bean_car_type;
import model.Bean_website;
import util.BaseException;

public class FrmCar extends JDialog implements ActionListener {
    
    private JPanel toolBar = new JPanel();
    private JButton btnAdd = new JButton("添加车辆");
    private JButton btnDelete = new JButton("删除车辆");
    private Object tblTitle[]={"车辆编号","车类名称","网点名称", "车牌号", "车型名称", "车辆状态", "日租金"};
    private Object tblData[][];
    DefaultTableModel tablmod=new DefaultTableModel();
    private JTable carTable=new JTable(tablmod);
    private final JButton btnModify = new JButton("修改车辆信息");

    private List<Bean_car_info> cars;

    private void reloadCarTable(){
        try {
            cars =(new Car()).loadAllCar();
            tblData =new Object[cars.size()][7];
            for(int i=0;i<cars.size();i++){
                tblData[i][0]=cars.get(i).getCar_id();
                tblData[i][1]=cars.get(i).getModel_name();
                tblData[i][2]=cars.get(i).getWeb_name();
                tblData[i][3]=cars.get(i).getPlate_num();
                tblData[i][4]=cars.get(i).getCar_model();
                tblData[i][5]=cars.get(i).getStaus();
                tblData[i][6]=cars.get(i).getPrice_day();

            }
            tablmod.setDataVector(tblData,tblTitle);
            this.carTable.validate();
            this.carTable.repaint();
        } catch (BaseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public FrmCar(Frame f, String s, boolean b) {
        super(f, s, b);

        toolBar.setLayout(new FlowLayout(FlowLayout.LEFT));
        toolBar.add(btnAdd);

        toolBar.add(btnModify);
        toolBar.add(this.btnDelete);
        this.getContentPane().add(toolBar, BorderLayout.NORTH);
        //提取现有数据
        this.reloadCarTable();
        this.getContentPane().add(new JScrollPane(this.carTable), BorderLayout.CENTER);

        // 屏幕居中显示
        this.setSize(800, 600);
        double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
        double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
        this.setLocation((int) (width - this.getWidth()) / 2,
                (int) (height - this.getHeight()) / 2);

        this.validate();

        this.btnAdd.addActionListener(this);
        this.btnModify.addActionListener(this);
        this.btnDelete.addActionListener(this);
        this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                //System.exit(0);
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub
            if(e.getSource()==this.btnAdd){
                FrmAddCar dlg=new FrmAddCar(this, "添加车辆", true);
                dlg.setVisible(true);
                if(dlg.getCar()!=null){//刷新表格
                    this.reloadCarTable();
                }
            }

            else if(e.getSource()==this.btnDelete){
            int i=this.carTable.getSelectedRow();
            if(i<0) {
                JOptionPane.showMessageDialog(null,  "请选择车辆","提示",JOptionPane.ERROR_MESSAGE);
                return;
            }
            if(JOptionPane.showConfirmDialog(this,"确定删除该车辆吗？","确认",JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION){
                int carid=Integer.valueOf(this.tblData[i][0].toString());
                try {
                    (new Car()).deleteCar(carid);
                    this.reloadCarTable();
                } catch (BaseException e1) {
                    JOptionPane.showMessageDialog(null, e1.getMessage(),"错误",JOptionPane.ERROR_MESSAGE);
                }

            }
        }
        else if(e.getSource()==this.btnModify) {
            int i=this.carTable.getSelectedRow();
            if(i<0) {
                JOptionPane.showMessageDialog(null,  "请选择车辆","提示",JOptionPane.ERROR_MESSAGE);
                return;
            }

            Bean_car_info car=this.cars.get(i);
            FrmModifyCar dlg=new FrmModifyCar(this,"修改车辆信息",true,car);
            dlg.setVisible(true);
            if(dlg.getCar()!=null){//刷新表格
                this.reloadCarTable();
            }
        }
    }
}
