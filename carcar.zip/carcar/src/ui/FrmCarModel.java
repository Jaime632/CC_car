package ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import control.CarModel;
import model.Bean_car_model_info;
import util.BaseException;

public class FrmCarModel extends JDialog implements ActionListener {
    private JPanel toolBar = new JPanel();
    private JButton btnAdd = new JButton("添加车型");
    private JButton btnDelete = new JButton("删除车型");
    private Object tblTitle[]={"车型名字", "品牌", "排量", "排挡", "座位数", "价格"};
    private Object tblData[][];
    DefaultTableModel tablmod=new DefaultTableModel();
    private JTable modelTable=new JTable(tablmod);
    private final JButton btnModifyModel = new JButton("修改车型信息");
    private List<Bean_car_model_info> models;
    private void reloadModelTable(){
        try {
            models=(new CarModel()).loadAllCarModel();
            tblData =new Object[models.size()][6];
            for(int i=0;i<models.size();i++){
                tblData[i][0]=models.get(i).getModel_name();
                tblData[i][1]=models.get(i).getBrand();
                tblData[i][2]=models.get(i).getDisplacement();
                tblData[i][3]=models.get(i).getGear();
                tblData[i][4]=models.get(i).getSeat_number();
                tblData[i][5]=models.get(i).getPrice();

            }
            tablmod.setDataVector(tblData,tblTitle);
            this.modelTable.validate();
            this.modelTable.repaint();
        } catch (BaseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public FrmCarModel(Frame f, String s, boolean b) {
        super(f, s, b);
        toolBar.setLayout(new FlowLayout(FlowLayout.LEFT));
        toolBar.add(btnAdd);

        toolBar.add(btnModifyModel);
        toolBar.add(this.btnDelete);
        this.getContentPane().add(toolBar, BorderLayout.NORTH);
        //提取现有数据
        this.reloadModelTable();
        this.getContentPane().add(new JScrollPane(this.modelTable), BorderLayout.CENTER);

        // 屏幕居中显示
        this.setSize(800, 600);
        double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
        double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
        this.setLocation((int) (width - this.getWidth()) / 2,
                (int) (height - this.getHeight()) / 2);

        this.validate();

        this.btnAdd.addActionListener(this);
        this.btnModifyModel.addActionListener(this);
        this.btnDelete.addActionListener(this);
        this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                //System.exit(0);
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub
        if(e.getSource()==this.btnAdd){
            FrmAddCarModel dlg=new FrmAddCarModel(this, "添加车类", true);
            dlg.setVisible(true);
            if(dlg.getType()!=null){//刷新表格
                this.reloadModelTable();
            }
        }

        else if(e.getSource()==this.btnDelete){
            int i=this.modelTable.getSelectedRow();
            if(i<0) {
                JOptionPane.showMessageDialog(null,  "请选择车型","提示",JOptionPane.ERROR_MESSAGE);
                return;
            }
            if(JOptionPane.showConfirmDialog(this,"确定删除该车型吗？","确认",JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION){

                String ModelName = this.tblData[i][0].toString();

                try {
                    (new CarModel()).deleteModel(ModelName);
                    this.reloadModelTable();
                } catch (BaseException e1) {
                    JOptionPane.showMessageDialog(null, e1.getMessage(),"错误",JOptionPane.ERROR_MESSAGE);
                }

            }
        }
        else if(e.getSource()==this.btnModifyModel) {
            int i=this.modelTable.getSelectedRow();
            if(i<0) {
                JOptionPane.showMessageDialog(null,  "请选择车型","提示",JOptionPane.ERROR_MESSAGE);
                return;
            }

            Bean_car_model_info type2 = this.models.get(i);
            FrmModifyCarModel dlg=new FrmModifyCarModel(this,"修改车型信息",true,type2);
            dlg.setVisible(true);
            if(dlg.getType()!=null){//刷新表格
                this.reloadModelTable();
            }
        }
    }
}