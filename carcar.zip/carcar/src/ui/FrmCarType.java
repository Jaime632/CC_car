package ui;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import control.CarType;
import control.CarType;
import model.Bean_car_type;
import util.BaseException;

public class FrmCarType extends JDialog implements ActionListener {
    private JPanel toolBar = new JPanel();
    private JButton btnAdd = new JButton("添加车类");
    private JButton btnDelete = new JButton("删除车类");
    private Object tblTitle[]={"车类名字", "车类描述"};
    private Object tblData[][];
    DefaultTableModel tablmod=new DefaultTableModel();
    private JTable typeTable=new JTable(tablmod);
    private final JButton btnModifyDes = new JButton("修改车类描述");
    private List<Bean_car_type> types;

    private void reloadTypeTable(){
        try {
            types=(new CarType()).loadAllCarType();
            tblData =new Object[types.size()][2];
            for(int i=0;i<types.size();i++){
                tblData[i][0]=types.get(i).getType_name();
                tblData[i][1]=types.get(i).getType_des();

            }
            tablmod.setDataVector(tblData,tblTitle);
            this.typeTable.validate();
            this.typeTable.repaint();
        } catch (BaseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public FrmCarType(Frame f, String s, boolean b) {
        super(f, s, b);
        toolBar.setLayout(new FlowLayout(FlowLayout.LEFT));
        toolBar.add(btnAdd);

        toolBar.add(btnModifyDes);
        toolBar.add(this.btnDelete);
        this.getContentPane().add(toolBar, BorderLayout.NORTH);
        //提取现有数据
        this.reloadTypeTable();
        this.getContentPane().add(new JScrollPane(this.typeTable), BorderLayout.CENTER);

        // 屏幕居中显示
        this.setSize(800, 600);
        double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
        double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
        this.setLocation((int) (width - this.getWidth()) / 2,
                (int) (height - this.getHeight()) / 2);

        this.validate();

        this.btnAdd.addActionListener(this);
        this.btnModifyDes.addActionListener(this);
        this.btnDelete.addActionListener(this);
        this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                //System.exit(0);
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub
        if(e.getSource()==this.btnAdd){

            FrmAddCarType dlg=new FrmAddCarType(this, "添加车类", true);
            dlg.setVisible(true);
            if(dlg.getCarType()!=null){//刷新表格
                this.reloadTypeTable();
            }
        }
        else if(e.getSource()==this.btnDelete){
        int i=this.typeTable.getSelectedRow();
        if(i<0) {
            JOptionPane.showMessageDialog(null,  "请选择车类","提示",JOptionPane.ERROR_MESSAGE);
            return;
        }
        if(JOptionPane.showConfirmDialog(this,"确定删除该车类吗？","确认",JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION){
            String type_name = String.valueOf(this.tblData[i][0]);
            try {
                (new CarType()).deleteType(type_name);
                this.reloadTypeTable();
            } catch (BaseException e1) {
                JOptionPane.showMessageDialog(null, e1.getMessage(),"错误",JOptionPane.ERROR_MESSAGE);
            }

         }
        }
        else if(e.getSource()==this.btnModifyDes) {
            int i=this.typeTable.getSelectedRow();
            if(i<0) {
                JOptionPane.showMessageDialog(null,  "请选择车类","提示",JOptionPane.ERROR_MESSAGE);
                return;
            }

            Bean_car_type type=this.types.get(i);
            FrmModifyCarType dlg=new FrmModifyCarType(this,"修改车类描述",true, type);
            dlg.setVisible(true);

            if(dlg.getType()!=null){//刷新表格
                this.reloadTypeTable();
            }
        }
    }
}
