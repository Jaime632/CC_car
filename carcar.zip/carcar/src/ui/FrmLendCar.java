package ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import control.*;
import model.*;
import util.BaseException;

public class FrmLendCar extends JDialog implements ActionListener {

    private JPanel toolBar = new JPanel();
    private JButton btnAdd = new JButton("租车");

    private JButton btnSelect = new JButton("选择租车网点");

    private Object tblTitle[]={"车类名称","网点名称", "车牌号", "车型名称", "车辆状态", "租金"};
    private Object tblData[][];
    DefaultTableModel tablmod=new DefaultTableModel();
    private JTable carTable=new JTable(tablmod);

    private Bean_car_info cord=null;

    private List<Bean_car_info> cars;

    private void reloadCarTable(){
        try {
            cars =(new Car()).loadAllCar();
            tblData =new Object[cars.size()][7];
            for(int i=0;i<cars.size();i++){
                tblData[i][0]=cars.get(i).getModel_name();
                tblData[i][1]=cars.get(i).getWeb_name();
                tblData[i][2]=cars.get(i).getPlate_num();
                tblData[i][3]=cars.get(i).getCar_model();
                tblData[i][4]=cars.get(i).getStaus();
                tblData[i][5]=cars.get(i).getPrice_day();

            }
            tablmod.setDataVector(tblData,tblTitle);
            this.carTable.validate();
            this.carTable.repaint();
        } catch (BaseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public FrmLendCar(Frame f, String s, boolean b) {
        super(f, s, b);

        toolBar.setLayout(new FlowLayout(FlowLayout.LEFT));
        toolBar.add(btnAdd);
        toolBar.add(btnSelect);
        this.getContentPane().add(toolBar, BorderLayout.NORTH);

        //提取现有数据
        this.reloadCarTable();
        this.getContentPane().add(new JScrollPane(this.carTable), BorderLayout.CENTER);

        // 屏幕居中显示
        this.setSize(900, 600);
        double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
        double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
        this.setLocation((int) (width - this.getWidth()) / 2,
                (int) (height - this.getHeight()) / 2);

        this.validate();

        this.btnAdd.addActionListener(this);
        this.btnSelect.addActionListener(this);
        this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                //System.exit(0);
            }
        });
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub

        if(e.getSource()==this.btnAdd){
            int i=this.carTable.getSelectedRow();
            if(i<0) {
                JOptionPane.showMessageDialog(null,  "请选择车辆","提示",JOptionPane.ERROR_MESSAGE);
                return;
            }
            if(JOptionPane.showConfirmDialog(this,"确定租用该车辆吗？","确认",JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION){

                Bean_car_info bs=this.cars.get(i);

                FrmLendCarTime dlg=new FrmLendCarTime(this,"租车天数",true, bs);
                dlg.setVisible(true);
                this.reloadCarTable();
                }

            }

        else if(e.getSource()==this.btnSelect){


            FrmSelectCar dlg = new FrmSelectCar(this,"选择网点",true);
            dlg.setVisible(true);
//            int i=this.carTable.getSelectedRow();
//            if(i<0) {
//                JOptionPane.showMessageDialog(null,  "请选择网点","提示",JOptionPane.ERROR_MESSAGE);
//                return;
//            }
//            if(JOptionPane.showConfirmDialog(this,"确定归还该车辆吗？","确认",JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION){
//                String webname = this.tblData[i][0].toString();
//
//                (new CarLend()).RenCar(carid);
//                this.reloadCarTable();
//
//            }
        }

        }




}