package ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import control.UserManager;
import control.WebManager;
import model.Bean_user_manage;
import model.Bean_website;
import util.BaseException;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

public class FrmModifyPwd extends JDialog implements ActionListener {
    private Bean_user_manage us;
    private Bean_website web=null;

    private JPanel toolBar = new JPanel();
    private JPanel workPane = new JPanel();
    private JButton btnOk = new JButton("确定");
    private JButton btnCancel = new JButton("取消");

    private JLabel labelName = new JLabel("账号：");
    private JLabel labelAddress = new JLabel("密码：");
    
    private JTextField edtName = new JTextField(20);
    private JTextField edtAddress = new JTextField(20);

    public FrmModifyPwd(JDialog f, String s, boolean b, Bean_user_manage us) {
        super(f, s, b);
        this.us = us;
        toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
        toolBar.add(btnOk);
        toolBar.add(btnCancel);
        this.getContentPane().add(toolBar, BorderLayout.SOUTH);
        edtName.setBounds(78, 37, 126, 21);
        this.edtName.setText(us.getUser_id());
        edtAddress.setBounds(78, 98, 126, 21);
        this.edtAddress.setText(us.getUser_pwd());
        this.getContentPane().add(workPane, BorderLayout.CENTER);
        workPane.setLayout(null);
        labelName.setBounds(24, 40, 60, 15);
        workPane.add(labelName);
        workPane.add(edtName);
        labelAddress.setBounds(24, 101, 60, 15);
        workPane.add(labelAddress);
        workPane.add(edtAddress);
        this.setSize(300, 244);
        // 屏幕居中显示
        double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
        double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
        this.setLocation((int) (width - this.getWidth()) / 2,
                (int) (height - this.getHeight()) / 2);

        this.validate();
        this.btnOk.addActionListener(this);
        this.btnCancel.addActionListener(this);
        this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                FrmModifyPwd.this.us=null;
            }
        });
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==this.btnCancel) {
            this.setVisible(false);
            this.us=null;
            return;
        }
        else if(e.getSource()==this.btnOk){
            us.setUser_id(this.edtName.getText());
            us.setUser_pwd(this.edtAddress.getText());
            try {
                (new UserManager()).changeUser(us);
                this.setVisible(false);
            } catch (BaseException e1) {
                JOptionPane.showMessageDialog(null, e1.getMessage(),"错误",JOptionPane.ERROR_MESSAGE);
            }

        }


    }
    public Bean_user_manage getUs() {
        return us;
    }

}
