package ui;

import java.awt.*;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import control.UserManager;
import model.Bean_customer;
import model.Bean_user_manage;
import util.BaseException;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JRadioButton;


public class FrmLogin extends JDialog implements ActionListener {
    private JPanel toolBar = new JPanel();
    private JPanel workPane = new JPanel();
    private JButton btnLogin = new JButton("登陆");
    private JButton btnCancel = new JButton("退出");
    private JButton btnRegister = new JButton("注册");

    private JLabel labelUser = new JLabel("用户：");
    private JLabel labelPwd = new JLabel("密码：");
    private JTextField edtUserId = new JTextField(20);
    private JPasswordField edtPwd = new JPasswordField(20);

    public FrmLogin(Frame f, String s, boolean b) {
        super(f, s, b);
        toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
        toolBar.add(this.btnRegister);
        toolBar.add(btnLogin);
        toolBar.add(btnCancel);
        this.getContentPane().add(toolBar, BorderLayout.SOUTH);
        this.getContentPane().add(workPane, BorderLayout.CENTER);
        workPane.add(labelUser);
        workPane.add(edtUserId);
        workPane.add(labelPwd);
        workPane.add(edtPwd);
        this.getContentPane().add(workPane, BorderLayout.CENTER);
        this.setSize(330, 170);
// 屏幕居中显示
        double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
        double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
        this.setLocation((int) (width - this.getWidth()) / 2,
                (int) (height - this.getHeight()) / 2);

        this.validate();

//        btnLogin.addActionListener(this);
//        btnCancel.addActionListener(this);
//        this.btnRegister.addActionListener(this);
//        this.addWindowListener(new WindowAdapter() {
//            public void windowClosing(WindowEvent e) {
//                System.exit(0);
//            }
//        });



        GroupLayout gl_workPane = new GroupLayout(workPane);
        gl_workPane.setHorizontalGroup(
        	gl_workPane.createParallelGroup(Alignment.LEADING)
        		.addGroup(gl_workPane.createSequentialGroup()
        			.addGroup(gl_workPane.createParallelGroup(Alignment.LEADING)
        				.addGroup(gl_workPane.createSequentialGroup()
        					.addGap(49)
        					.addComponent(labelUser)
        					.addGap(5)
        					.addComponent(edtUserId, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
        				.addGroup(gl_workPane.createSequentialGroup()
        					.addGap(50)
        					.addGroup(gl_workPane.createParallelGroup(Alignment.LEADING)
        						.addGroup(gl_workPane.createSequentialGroup()
        							.addComponent(labelPwd)
        							.addPreferredGap(ComponentPlacement.RELATED)
        							.addComponent(edtPwd, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))))
        			.addGap(90))
        );
        gl_workPane.setVerticalGroup(
        	gl_workPane.createParallelGroup(Alignment.LEADING)
        		.addGroup(gl_workPane.createSequentialGroup()
        			.addGap(5)
        			.addGroup(gl_workPane.createParallelGroup(Alignment.LEADING)
        				.addGroup(gl_workPane.createSequentialGroup()
        					.addGap(3)
        					.addComponent(labelUser))
        				.addComponent(edtUserId, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
        			.addGap(5)
        			.addGroup(gl_workPane.createParallelGroup(Alignment.BASELINE)
        				.addComponent(edtPwd, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        				.addComponent(labelPwd))
        			.addGap(18)
        			.addContainerGap(15, Short.MAX_VALUE))
        );
        workPane.setLayout(gl_workPane);
        this.setSize(310, 180);

        btnLogin.addActionListener(this);
        btnCancel.addActionListener(this);
        this.btnRegister.addActionListener(this);
        this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
        this.setTitle("登录");
        this.setVisible(true);
    }



    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == this.btnLogin) {
            UserManager sum=new UserManager();
            String userid=this.edtUserId.getText();
            String pwd=new String(this.edtPwd.getPassword());
            try {
                Bean_user_manage user=sum.loadUser(userid);
                if(pwd.equals(user.getUser_pwd())){
                    UserManager.currentUser=user;
                    setVisible(false);
                }
                else{
                    JOptionPane.showMessageDialog(null,  "密码错误","错误提示",JOptionPane.ERROR_MESSAGE);
                }
            } catch (BaseException e1) {
                JOptionPane.showMessageDialog(null, e1.getMessage(), "错误提示",JOptionPane.ERROR_MESSAGE);
            }


        } else if (e.getSource() == this.btnCancel) {
            System.exit(0);
        } else if(e.getSource() == this.btnRegister) {
            FrmRegister dlg = new FrmRegister(this,"注册",true);
            dlg.setVisible(true);

        }
    }

}
