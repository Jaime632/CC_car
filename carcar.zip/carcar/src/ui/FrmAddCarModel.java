package ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import control.CarModel;
import model.Bean_car_model_info;
import util.BaseException;

public class FrmAddCarModel extends JDialog implements ActionListener {
	private Bean_car_model_info model=null;
//"车型名称","品牌","排量","排挡","座位数","价格"
	private JPanel toolBar = new JPanel();
	private JPanel workPane = new JPanel();
	private JButton btnOk = new JButton("确定");
	private JButton btnCancel = new JButton("取消");

	private JLabel labelTypeName = new JLabel("车型名称：");
	private JLabel labelDescrb = new JLabel("品牌：");

	private JTextField edt1 = new JTextField(20);
	private JTextField edt2 = new JTextField(20);
	private JTextField edt3;
	private JTextField edt4;
	private JTextField edt5;
	private JTextField edt6;

	public FrmAddCarModel(JDialog f, String s, boolean b) {
		super(f, s, b);
		toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
		toolBar.add(btnOk);
		toolBar.add(btnCancel);
		this.getContentPane().add(toolBar, BorderLayout.SOUTH);
		this.getContentPane().add(workPane, BorderLayout.WEST);
		workPane.setLayout(null);
		labelTypeName.setBounds(10, 42, 77, 15);
		workPane.add(labelTypeName);
		edt1.setBounds(116, 39, 126, 21);
		workPane.add(edt1);
		labelDescrb.setBounds(10, 67, 77, 15);
		workPane.add(labelDescrb);
		edt2.setBounds(116, 64, 126, 21);
		workPane.add(edt2);
		this.getContentPane().add(workPane, BorderLayout.CENTER);

		JLabel labelDescrb_1 = new JLabel("排量：");
		labelDescrb_1.setBounds(10, 92, 77, 15);
		workPane.add(labelDescrb_1);

		edt3 = new JTextField(20);
		edt3.setBounds(116, 89, 126, 21);
		workPane.add(edt3);

		JLabel labelDescrb_1_1 = new JLabel("排挡：");
		labelDescrb_1_1.setBounds(10, 117, 77, 15);
		workPane.add(labelDescrb_1_1);

		JLabel labelDescrb_1_2 = new JLabel("座位数：");
		labelDescrb_1_2.setBounds(10, 142, 77, 15);
		workPane.add(labelDescrb_1_2);

		JLabel labelDescrb_1_3 = new JLabel("价格：");
		labelDescrb_1_3.setBounds(10, 167, 77, 15);
		workPane.add(labelDescrb_1_3);

		edt4 = new JTextField(20);
		edt4.setBounds(116, 114, 126, 21);
		workPane.add(edt4);

		edt5 = new JTextField(20);
		edt5.setBounds(116, 139, 126, 21);
		workPane.add(edt5);

		edt6 = new JTextField(20);
		edt6.setBounds(116, 164, 126, 21);
		workPane.add(edt6);
		this.setSize(301, 326);
		// 屏幕居中显示
		double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		this.setLocation((int) (width - this.getWidth()) / 2,
				(int) (height - this.getHeight()) / 2);

		this.validate();
		this.btnOk.addActionListener(this);
		this.btnCancel.addActionListener(this);

	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.btnCancel) {
			this.setVisible(false);
			return;
		}
		else if(e.getSource()==this.btnOk){

			String t1=this.edt1.getText();
			String t2=this.edt2.getText();
			String t3=this.edt3.getText();
			String t4=this.edt4.getText();
			String t5=this.edt5.getText();
			String t6=this.edt6.getText();

			model=new Bean_car_model_info();
			model.setModel_name(t1);;
			model.setBrand(t2);
			model.setDisplacement(t3);
			model.setGear(t4);
			model.setSeat_number(t5);
			model.setPrice(Double.valueOf(t6));


			try {
				(new CarModel()).createModel(model);
				this.setVisible(false);
			} catch (BaseException e2) {
				this.model=null;
				JOptionPane.showMessageDialog(null, e2.getMessage(),"错误",JOptionPane.ERROR_MESSAGE);
			}
		}

	}
//	public Bean_car_model_info getCarType() {
//		return model;
//	}
}
