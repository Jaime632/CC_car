package ui;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import control.WebManager;
import model.Bean_website;
import util.BaseException;

public class FrmWeb extends JDialog implements ActionListener {
    private JPanel toolBar = new JPanel();
    private JButton btnAdd = new JButton("添加网点");
    private JButton btnDelete = new JButton("删除网点");
    private Object tblTitle[]={"网点名称","所属城市", "地址", "电话号码"};
    private Object tblData[][];
    DefaultTableModel tablmod=new DefaultTableModel();
    private JTable webSiteTable=new JTable(tablmod);
    private final JButton btnModifyWeb = new JButton("修改网点信息");
    private List<Bean_website> webs;
    private void reloadWebSiteTable(){
        try {
            webs=(new WebManager()).loadAllWebSite();
            tblData =new Object[webs.size()][4];
            for(int i=0;i<webs.size();i++){
                tblData[i][0]=webs.get(i).getWeb_name();
                tblData[i][1]=webs.get(i).getCity();
                tblData[i][2]=webs.get(i).getAddress();
                tblData[i][3]=webs.get(i).getPhone_num();

            }
            tablmod.setDataVector(tblData,tblTitle);
            this.webSiteTable.validate();
            this.webSiteTable.repaint();
        } catch (BaseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public FrmWeb(Frame f, String s, boolean b) {
        super(f, s, b);
        toolBar.setLayout(new FlowLayout(FlowLayout.LEFT));
        toolBar.add(btnAdd);

        toolBar.add(btnModifyWeb);
        toolBar.add(this.btnDelete);
        this.getContentPane().add(toolBar, BorderLayout.NORTH);
        //提取现有数据
        this.reloadWebSiteTable();
        this.getContentPane().add(new JScrollPane(this.webSiteTable), BorderLayout.CENTER);

        // 屏幕居中显示
        this.setSize(800, 600);
        double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
        double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
        this.setLocation((int) (width - this.getWidth()) / 2,
                (int) (height - this.getHeight()) / 2);

        this.validate();

        this.btnAdd.addActionListener(this);
        this.btnModifyWeb.addActionListener(this);
        this.btnDelete.addActionListener(this);
        this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                //System.exit(0);
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub
        if(e.getSource()==this.btnAdd){
            FrmAddWeb dlg=new FrmAddWeb(this,"添加网点",true);
            dlg.setVisible(true);
            if(dlg.getweb()!=null){//刷新表格
                this.reloadWebSiteTable();
            }
        }

        else if(e.getSource()==this.btnDelete){
            int i=this.webSiteTable.getSelectedRow();
            if(i<0) {
                JOptionPane.showMessageDialog(null,  "请选择网点","提示",JOptionPane.ERROR_MESSAGE);
                return;
            }
            if(JOptionPane.showConfirmDialog(this,"确定删除网点吗？","确认",JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION){
                String web_name = this.tblData[i][0].toString();
                try {
                    (new WebManager()).deleteWeb(web_name);
                    this.reloadWebSiteTable();
                } catch (BaseException e1) {
                    JOptionPane.showMessageDialog(null, e1.getMessage(),"错误",JOptionPane.ERROR_MESSAGE);
                }

            }
        }
        else if(e.getSource()==this.btnModifyWeb) {
            int i=this.webSiteTable.getSelectedRow();
            if(i<0) {
                JOptionPane.showMessageDialog(null,  "请选择网点","提示",JOptionPane.ERROR_MESSAGE);
                return;
            }
            Bean_website web=this.webs.get(i);
            FrmModifyWeb dlg=new FrmModifyWeb(this,"修改网点信息",true,web);
            dlg.setVisible(true);
            if(dlg.getWeb()!=null){//刷新表格
                this.reloadWebSiteTable();
            }
        }
    }
}
