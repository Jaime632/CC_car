package ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import control.CarType;
import model.Bean_car_type;
import model.Bean_website;
import util.BaseException;

public class FrmAddCarType extends JDialog implements ActionListener {
	private Bean_car_type type=null;

	private JPanel toolBar = new JPanel();
	private JPanel workPane = new JPanel();
	private JButton btnOk = new JButton("确定");
	private JButton btnCancel = new JButton("取消");
	private JLabel labelTypeName = new JLabel("车类名称：");
	private JLabel labelDescrb = new JLabel("描述：");

	private JTextField edtTypeName = new JTextField(20);
	private JTextField edtDescrb = new JTextField(20);

	public FrmAddCarType(JDialog f, String s, boolean b) {
		super(f, s, b);

		toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
		toolBar.add(btnOk);
		toolBar.add(btnCancel);
		this.getContentPane().add(toolBar, BorderLayout.SOUTH);
		this.getContentPane().add(workPane, BorderLayout.WEST);
		workPane.setLayout(null);
		labelTypeName.setBounds(10, 42, 77, 15);
		workPane.add(labelTypeName);
		edtTypeName.setBounds(116, 39, 126, 21);
		workPane.add(edtTypeName);
		labelDescrb.setBounds(10, 67, 77, 15);
		workPane.add(labelDescrb);
		edtDescrb.setBounds(116, 64, 126, 71);
		workPane.add(edtDescrb);
		this.getContentPane().add(workPane, BorderLayout.CENTER);
		this.setSize(300, 236);
		// 屏幕居中显示
		double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		this.setLocation((int) (width - this.getWidth()) / 2,
				(int) (height - this.getHeight()) / 2);

		this.validate();
		this.btnOk.addActionListener(this);
		this.btnCancel.addActionListener(this);

	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.btnCancel) {
			this.setVisible(false);
			return;
		}
		else if(e.getSource()==this.btnOk){

			String typeName=this.edtTypeName.getText();
			String typeDescrb=this.edtDescrb.getText();

			type=new Bean_car_type();
			type.setType_name(typeName);;
			type.setType_des(typeDescrb);
			try {
				(new CarType()).createType(type);
				this.setVisible(false);
			} catch (BaseException e2) {
				this.type=null;
				JOptionPane.showMessageDialog(null, e2.getMessage(),"错误",JOptionPane.ERROR_MESSAGE);
			}
		}

	}
	public Bean_car_type getCarType() {
		return type;
	}
}
