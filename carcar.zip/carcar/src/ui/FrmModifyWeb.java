package ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import control.WebManager;
import model.Bean_website;
import util.BaseException;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

public class FrmModifyWeb extends JDialog implements ActionListener {
    private Bean_website web=null;

    private JPanel toolBar = new JPanel();
    private JPanel workPane = new JPanel();
    private JButton btnOk = new JButton("确定");
    private JButton btnCancel = new JButton("取消");
    private JLabel labelName = new JLabel("名称：");
    private JLabel labelAddress = new JLabel("地址：");
    private JTextField edtName = new JTextField(20);
    private JTextField edtAddress = new JTextField(20);
    private final JLabel lblCity = new JLabel("城市：");
    private final JTextField edtCity = new JTextField();
    private final JLabel lblTelNum = new JLabel("电话：");
    private final JTextField edtTelNum = new JTextField();
    public FrmModifyWeb(JDialog f, String s, boolean b,Bean_website web) {
        super(f, s, b);
        edtTelNum.setBounds(78, 129, 126, 21);
        this.edtTelNum.setText(web.getPhone_num());
        edtTelNum.setColumns(10);
        edtCity.setBounds(78, 68, 126, 21);
        this.edtCity.setText(web.getCity());
        edtCity.setColumns(10);
        this.web=web;
        toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
        toolBar.add(btnOk);
        toolBar.add(btnCancel);
        this.getContentPane().add(toolBar, BorderLayout.SOUTH);

        edtName.setBounds(78, 37, 126, 21);
        this.edtName.setText(web.getWeb_name());
        edtAddress.setBounds(78, 98, 126, 21);
        this.edtAddress.setText(web.getAddress());
        this.getContentPane().add(workPane, BorderLayout.CENTER);
        workPane.setLayout(null);

        labelName.setBounds(24, 40, 44, 15);
        workPane.add(labelName);
        workPane.add(edtName);
        labelAddress.setBounds(24, 101, 44, 15);
        workPane.add(labelAddress);
        workPane.add(edtAddress);
        lblCity.setBounds(24, 71, 44, 15);
        workPane.add(lblCity);
        workPane.add(edtCity);
        lblTelNum.setBounds(24, 132, 44, 15);
        workPane.add(lblTelNum);
        workPane.add(edtTelNum);
        this.setSize(300, 244);
        // 屏幕居中显示
        double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
        double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
        this.setLocation((int) (width - this.getWidth()) / 2,
                (int) (height - this.getHeight()) / 2);

        this.validate();
        this.btnOk.addActionListener(this);
        this.btnCancel.addActionListener(this);
        this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                FrmModifyWeb.this.web=null;
            }
        });
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==this.btnCancel) {
            this.setVisible(false);
            this.web=null;
            return;
        }
        else if(e.getSource()==this.btnOk){
            web.setWeb_name(this.edtName.getText());
            web.setCity(this.edtCity.getText());
            web.setAddress(this.edtAddress.getText());
            web.setPhone_num(this.edtTelNum.getText());
            try {
                (new WebManager()).modifyWebSite(web);
                this.setVisible(false);
            } catch (BaseException e1) {
                JOptionPane.showMessageDialog(null, e1.getMessage(),"错误",JOptionPane.ERROR_MESSAGE);
            }
        }

    }
    public Bean_website getWeb() {
        return web;
    }

}
