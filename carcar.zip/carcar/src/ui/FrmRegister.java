package ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import control.UserManager;
import model.Bean_customer;
import util.BaseException;

public class FrmRegister extends JDialog implements ActionListener {

//"名称","性别","密码","手机号","邮箱","城市"

	private JPanel toolBar = new JPanel();
	private JPanel workPane = new JPanel();
	private JButton btnOk = new JButton("确定");
	private JButton btnCancel = new JButton("取消");
	private Bean_customer user = null;
	private JLabel labelName = new JLabel("用户名：");
	private JLabel labelSex = new JLabel("性别：");

	private JTextField edt1 = new JTextField(20);
	private JTextField edt2 = new JTextField(20);
	private JTextField edt3;
	private JTextField edt4;
	private JTextField edt5;
	private JTextField edt6;

	public FrmRegister(JDialog f, String s, boolean b) {
		super(f, s, b);
//		edtTypeId.setBounds(116, 14, 126, 21);
//		edtTypeId.setColumns(10);
		toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
		toolBar.add(btnOk);
		toolBar.add(btnCancel);
		this.getContentPane().add(toolBar, BorderLayout.SOUTH);
		this.getContentPane().add(workPane, BorderLayout.WEST);
		workPane.setLayout(null);
		labelName.setBounds(10, 42, 77, 15);
		workPane.add(labelName);
		edt1.setBounds(116, 39, 126, 21);
		workPane.add(edt1);
		labelSex.setBounds(10, 67, 77, 15);
		workPane.add(labelSex);
		edt2.setBounds(116, 64, 126, 21);
		workPane.add(edt2);
		this.getContentPane().add(workPane, BorderLayout.CENTER);

		JLabel labelSex_1 = new JLabel("密码：");
		labelSex_1.setBounds(10, 92, 77, 15);
		workPane.add(labelSex_1);

		edt3 = new JTextField(20);
		edt3.setBounds(116, 89, 126, 21);
		workPane.add(edt3);

		JLabel labelSex_1_1 = new JLabel("手机号：");
		labelSex_1_1.setBounds(10, 117, 77, 15);
		workPane.add(labelSex_1_1);

		JLabel labelSex_1_2 = new JLabel("邮箱：");
		labelSex_1_2.setBounds(10, 142, 77, 15);
		workPane.add(labelSex_1_2);

		JLabel labelSex_1_3 = new JLabel("城市：");
		labelSex_1_3.setBounds(10, 167, 77, 15);
		workPane.add(labelSex_1_3);

		edt4 = new JTextField(20);
		edt4.setBounds(116, 114, 126, 21);
		workPane.add(edt4);

		edt5 = new JTextField(20);
		edt5.setBounds(116, 139, 126, 21);
		workPane.add(edt5);

		edt6 = new JTextField(20);
		edt6.setBounds(116, 164, 126, 21);
		workPane.add(edt6);
		this.setSize(301, 326);
		// 屏幕居中显示
		double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		this.setLocation((int) (width - this.getWidth()) / 2,
				(int) (height - this.getHeight()) / 2);

		this.validate();
		this.btnOk.addActionListener(this);
		this.btnCancel.addActionListener(this);

	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.btnCancel) {
			this.setVisible(false);
			return;
		}
		else if(e.getSource()==this.btnOk){
			user = new Bean_customer();
			user.setCustomer_id(edt1.getText().toString());
			user.setSex(edt2.getText().toString());
			user.setPassWord(edt3.getText().toString());
			user.setPhone_number(edt4.getText().toString());
			user.setMailbox(edt5.getText().toString());
			user.setCity(edt6.getText().toString());

			try {
				(new UserManager()).createUser2(user);
				this.setVisible(false);
			} catch (BaseException e2) {
//				this.user=null;
				JOptionPane.showMessageDialog(null, e2.getMessage(),"错误",JOptionPane.ERROR_MESSAGE);
			}
		}

	}
//	public Bean_customer getCarType() {
//		return model;
//	}
}
