package ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.*;

import control.UserManager;
import model.Bean_car_type;
import model.Bean_customer;

public class FrmMain extends JFrame implements ActionListener {
	private FrmLogin dlgLogin=null;
	private JPanel statusBar = new JPanel();

	//管理员菜单
	private JMenuBar main_bar = new JMenuBar(); ;
	//查
    private JMenu admin_sys = new JMenu("管理员主菜单");
//    private JMenuItem  customer_ord_sear = new JMenuItem("客户订单查询");
//    private JMenuItem  car_rent_sear = new JMenuItem("车辆租用查询");
	private final JMenuItem car_manage_sear = new JMenuItem("车辆调拨查询");
	//增,删
	private final JMenuItem user_manage = new JMenuItem("用户管理");
	private final JMenuItem website_manager = new JMenuItem("网点管理");
	private final JMenuItem car_type_manager = new JMenuItem("车类管理");
	private final JMenuItem car_model_manager = new JMenuItem("车型管理");
	private final JMenuItem car_manager = new JMenuItem("车辆管理");
	//用户菜单
	private final JMenu user_sys = new JMenu("用户中心");
	private final JMenuItem car_lend = new JMenuItem("租借车辆");
//	private final JMenuItem car_rent = new JMenuItem("归还车辆");
//	private final JMenuItem person_info = new JMenuItem("修改个人信息");
	private final JMenuItem order_info = new JMenuItem("订单信息查询");
//	private final JMenuItem website_car_info = new JMenuItem("网点车辆查询");

	public FrmMain(){
		this.setExtendedState(Frame.MAXIMIZED_BOTH);
		this.setTitle("欢迎使用cc租车系统");
		dlgLogin=new FrmLogin(this,"登陆",true);
		dlgLogin.setVisible(true);

		if("管理员".equals(UserManager.currentUser.getUser_type()))
		{
			main_bar.add(admin_sys);

			admin_sys.addActionListener(this);
			admin_sys.add(car_manage_sear);
			car_manage_sear.addActionListener(this);
			admin_sys.add(user_manage);
			user_manage.addActionListener(this);
			admin_sys.add(website_manager);
			website_manager.addActionListener(this);
			admin_sys.add(car_type_manager);
			car_type_manager.addActionListener(this);
			admin_sys.add(car_model_manager);
			car_model_manager.addActionListener(this);
			admin_sys.add(car_manager);
			car_manager.addActionListener(this);




		}
		
//		if("网点员工".equals(UserManager.currentUser.getUser_type()))
//    	{
//			menubar.add(menuSystemManager);
//	    	menuSystemManager.add(mntmCarRecordManager);
//	    	mntmCarRecordManager.addActionListener(this);
//    	}
//
	    if("用户".equals(UserManager.currentUser.getUser_type()))
	    {
			main_bar.add(user_sys);
//			user_sys.add(user_sys);

			user_sys.add(car_lend);
			car_lend.addActionListener(this);
//			user_sys.add(car_rent);
//			car_rent.addActionListener(this);
//			user_sys.add(person_info);
//			person_info.addActionListener(this);
			user_sys.add(order_info);
			order_info.addActionListener(this);
//			user_sys.add(website_car_info);
//			website_car_info.addActionListener(this);


	    }
	  
	    this.setJMenuBar(main_bar);
	    
	    //状态栏
	    statusBar.setLayout(new FlowLayout(FlowLayout.LEFT));
	    JLabel label=new JLabel("您好!"+UserManager.currentUser.getUser_id());
	    statusBar.add(label);
	    this.getContentPane().add(statusBar,BorderLayout.SOUTH);
	    this.addWindowListener(new WindowAdapter(){   
	    	public void windowClosing(WindowEvent e){ 
	    		System.exit(0);
             }
        });
	    this.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == this.user_manage)
		{
			FrmUserManage dlg = new FrmUserManage(this, "用户管理", true);
			dlg.setVisible(true);
		}
		else if(e.getSource() == this.car_type_manager)
		{
			FrmCarType dlg = new FrmCarType(this,"车类管理",true);
			dlg.setVisible(true);
		}
		else if(e.getSource() == this.car_model_manager)
		{
			FrmCarModel dlg = new FrmCarModel(this,"车型管理",true);
			dlg.setVisible(true);
		}

		else if(e.getSource() == this.website_manager)
		{
			FrmWeb dlg = new FrmWeb(this, "网点管理", true);
			dlg.setVisible(true);
		}

//		else if(e.getSource() == this.person_info)
//		{
//			Bean_customer cu = null;
//			FrmModifyPersonInfo dlg = new FrmModifyPersonInfo(this, "修改个人信息", true, cu);
//			dlg.setVisible(true);
//		}

		else if(e.getSource() == this.car_manager)
		{
			FrmCar dlg = new FrmCar(this, "车辆管理", true);
			dlg.setVisible(true);
		}
		else if(e.getSource() == this.car_lend)
		{
			FrmLendCar dlg = new FrmLendCar(this, "租车界面", true);
			dlg.setVisible(true);
		}
		else if(e.getSource() == this.order_info)
		{
			FrmCarOrd dlg = new FrmCarOrd(this,"订单查询",true);
			dlg.setVisible(true);
		}
		else if(e.getSource() == this.car_manage_sear)
		{
			FrmCarManage dlg= new FrmCarManage(this,"调拨查询",true);
			dlg.setVisible(true);
		}



	}
}
