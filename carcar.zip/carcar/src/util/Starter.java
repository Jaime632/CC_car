package util;

import ui.FrmMain;

public class Starter {

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        new FrmMain();
    }

}
