package control;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Bean_car_info;
import model.Bean_car_manage;
import model.Bean_car_ord;
import util.BaseException;
import util.BusinessException;
import util.DBUtil;
import util.DbException;

public class Car {
    public List<Bean_car_info>  loadAllCarSelect(String name) throws BaseException{
        List<Bean_car_info> result=new ArrayList<Bean_car_info>();
//        Bean_car_info webname = null;
        Connection conn=null;
        try {
            conn=DBUtil.getConnection();
            String sql="select car_id, model_name, web_name, plate_num, car_model, staus, price_day from car_info where web_name = ?";
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, name);
            java.sql.ResultSet rs=pst.executeQuery();
            while (rs.next()){
                Bean_car_info car=new Bean_car_info();
                car.setCar_id(rs.getInt(1));
                car.setModel_name(rs.getString(2));
                car.setWeb_name(rs.getString(3));
                car.setPlate_num(rs.getString(4));
                car.setCar_model(rs.getString(5));
                car.setStaus(rs.getString(6));
                car.setPrice_day(rs.getInt(7));
                result.add(car);
            }


            rs.close();
            pst.close();


        } catch (SQLException e) {
            e.printStackTrace();
            throw new DbException(e);
        }
        finally{
            if(conn!=null)
                try {
                    conn.close();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
        }
        return result;
    }





    public List<Bean_car_manage>  loadAllCarManage() throws BaseException{
        List<Bean_car_manage> result=new ArrayList<Bean_car_manage>();
        Connection conn=null;
        try {
            conn=DBUtil.getConnection();
            String sql="select manage_id, car_plate, manage_time, len_web_name, ren_web_name \n" +
                    "from car_manage\n" +
                    "order by manage_id";
            java.sql.Statement st=conn.createStatement();
            java.sql.ResultSet rs=st.executeQuery(sql);
            while(rs.next()){
                Bean_car_manage car=new Bean_car_manage();
                car.setManage_id(rs.getInt(1));
                car.setCar_plate(rs.getString(2));
                car.setManage_time(rs.getDate(3));
                car.setLen_web_name(rs.getString(4));
                car.setRen_web_name(rs.getString(5));
                result.add(car);
            }

            rs.close();
            st.close();

        } catch (SQLException e) {
            e.printStackTrace();
            throw new DbException(e);
        }
        finally{
            if(conn!=null)
                try {
                    conn.close();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
        }
        return result;
    }



    public List<Bean_car_ord>  loadAllCarOrd() throws BaseException{
        List<Bean_car_ord> result=new ArrayList<Bean_car_ord>();
        Connection conn=null;
        try {
            conn=DBUtil.getConnection();
            String sql="select ord_id, customer_id, car_plate, in_time, all_time, spend_money, len_web, status\n" +
                    "from car_ord\n" +
                    "order by ord_id";


            java.sql.Statement st=conn.createStatement();
            java.sql.ResultSet rs=st.executeQuery(sql);
            while(rs.next()){
                Bean_car_ord car=new Bean_car_ord();
                car.setOrd_id(rs.getInt(1));
                car.setCustomer_id(rs.getString(2));
                car.setCar_plate(rs.getString(3));
                car.setIn_time(rs.getDate(4));
                car.setAll_time(rs.getInt(5));
                car.setSpend_money(rs.getInt(6));
                car.setLen_web(rs.getString(7));
                car.setStatus(rs.getString(8));
                result.add(car);
            }

            rs.close();
            st.close();

        } catch (SQLException e) {
            e.printStackTrace();
            throw new DbException(e);
        }
        finally{
            if(conn!=null)
                try {
                    conn.close();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
        }
        return result;
    }


    public List<Bean_car_info>  loadAllCar() throws BaseException{
        List<Bean_car_info> result=new ArrayList<Bean_car_info>();
        Connection conn=null;
        try {
            conn=DBUtil.getConnection();
            String sql="select car_id, model_name, web_name, plate_num, car_model, staus, price_day\n" +
                    "from car_info ";



            java.sql.Statement st=conn.createStatement();
            java.sql.ResultSet rs=st.executeQuery(sql);
            while(rs.next()){
                Bean_car_info car=new Bean_car_info();
                car.setCar_id(rs.getInt(1));
                car.setModel_name(rs.getString(2));
                car.setWeb_name(rs.getString(3));
                car.setPlate_num(rs.getString(4));
                car.setCar_model(rs.getString(5));
                car.setStaus(rs.getString(6));
                car.setPrice_day(rs.getInt(7));
                result.add(car);
            }

            rs.close();
            st.close();

        } catch (SQLException e) {
            e.printStackTrace();
            throw new DbException(e);
        }
        finally{
            if(conn!=null)
                try {
                    conn.close();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
        }
        return result;
    }

    public void createCar(Bean_car_info car)throws BaseException{
        if(car.getPlate_num() == null || "".equals(car.getPlate_num())) throw new BusinessException("车牌号不能为空");
        if("".equals((car.getCar_model()+""))) throw new BusinessException("车型名称不能为空");
        if("".equals((car.getWeb_name()+""))) throw new BusinessException("网点名称不能为空");
        if(car.getStaus() == null || "".equals(car.getStaus())) throw new BusinessException("车辆状态不能为空");
        if("".equals((car.getModel_name()+""))) throw new BusinessException("车类名称不能为空");
        if("".equals(car.getPrice_day())) throw new BusinessException("日租金不能为空");

        Connection conn=null;
        try {
            conn=DBUtil.getConnection();
            String sql="select * from car_info where plate_num = ?";
            java.sql.PreparedStatement pst=conn.prepareStatement(sql);
            pst.setString(1,car.getPlate_num());
            java.sql.ResultSet rs=pst.executeQuery();
            if(rs.next()) throw new BusinessException("该车辆已经存在");
            rs.close();
            pst.close();

            sql="insert into car_info (model_name, web_name, plate_num, car_model, staus, price_day) values(?, ?, ?, ?, ?, ?)";
            pst=conn.prepareStatement(sql);
            pst.setString(1, car.getModel_name());
            pst.setString(2, car.getWeb_name());
            pst.setString(3, car.getPlate_num());
            pst.setString(4, car.getCar_model());
            pst.setString(5, car.getStaus());
            pst.setInt(6, car.getPrice_day());
            pst.execute();
            pst.close();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new DbException(e);
        }
        finally{
            if(conn!=null)
                try {
                    conn.close();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
        }
    }

    public void deleteCar(int carid)throws BaseException{
        Connection conn=null;
        try {
            conn=DBUtil.getConnection();
            String sql="select *\n" +
                    "from car_info\n" +
                    "where car_id = ?";
            java.sql.PreparedStatement pst=conn.prepareStatement(sql);
            pst.setInt(1,carid);
            java.sql.ResultSet rs=pst.executeQuery();
            if(!rs.next()) throw new BusinessException("该车辆不存在");
            rs.close();
            pst.close();

            sql = "delete from car_info where car_id = ?";
            pst = conn.prepareStatement(sql);
            pst.setInt(1, carid);
            pst.execute();
            pst.close();

        } catch (SQLException e) {
            e.printStackTrace();
            throw new DbException(e);
        }
        finally{
            if(conn!=null)
                try {
                    conn.close();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
        }
    }

    public void modifyCar(Bean_car_info car)throws BaseException{
        if(car.getPlate_num() == null || "".equals(car.getPlate_num())) throw new BusinessException("车牌号不能为空");
        if("".equals((car.getModel_name()+""))) throw new BusinessException("车型名称不能为空");
        if("".equals((car.getWeb_name()+""))) throw new BusinessException("网点名称不能为空");
        if(car.getStaus() == null || "".equals(car.getStaus())) throw new BusinessException("车辆状态不能为空");
        if("".equals((car.getWeb_name()+""))) throw new BusinessException("车类名称不能为空");
        if( "".equals(car.getPrice_day())) throw new BusinessException("日租金不能为空");

        Connection conn=null;
        try {
            conn=DBUtil.getConnection();
            String sql="update  car_info set model_name = ?, web_name = ?,  car_model = ?, staus = ? , price_day = ? where plate_num = ?";
            java.sql.PreparedStatement pst=conn.prepareStatement(sql);
            pst.setString(1, car.getModel_name());
            pst.setString(2, car.getWeb_name());
            pst.setString(3, car.getCar_model());
            pst.setString(4, car.getStaus());
            pst.setInt(5, car.getPrice_day());
            pst.setString(6, car.getPlate_num());
            pst.execute();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new DbException(e);
        }
        finally{
            if(conn!=null)
                try {
                    conn.close();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
        }

    }

//    public Bean_car_info searchCar(int carid) throws BaseException{
//        Connection conn=null;
//        Bean_car_info car=null;
//        try {
//            conn=DBUtil.getConnection();
//            String sql="select car_id, model_id, web_id, plate_num, car_model, staus from car_info where car_id =?";
//            java.sql.PreparedStatement pst=conn.prepareStatement(sql);
//            pst.setInt(1, carid);
//            java.sql.ResultSet rs=pst.executeQuery();
//            if(!rs.next()) throw new BusinessException("该车辆不存在");

//            car=new Bean_car_info();
//            car.setCar_id(rs.getInt(1));
//            car.setModel_name(rs.getString(2));
//            car.setWeb_name(rs.getString(3));
//            car.setPlate_num(rs.getString(4));
//            car.setCar_model(rs.getString(5));
//            car.setStaus(rs.getString(6));
//            rs.close();
//            pst.close();
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//            throw new DbException(e);
//        }
//        finally{
//            if(conn!=null)
//                try {
//                    conn.close();
//                } catch (SQLException e) {
//                    // TODO Auto-generated catch block
//                    e.printStackTrace();
//                }
//        }
//        return car;
//    }
}
