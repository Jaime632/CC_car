package control;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Bean_user_manage;
import model.Bean_website;
import util.BaseException;
import util.BusinessException;
import util.DBUtil;
import util.DbException;

public class WebManager {

    public List<Bean_website>  loadAllWebSite() throws BaseException{
        List<Bean_website> result=new ArrayList<Bean_website>();
        Connection conn=null;
        try {
            conn=DBUtil.getConnection();
            String sql="select web_name, city, address, phone_num\n" +
                    "from website\n" +
                    "order by web_name";
            java.sql.Statement st=conn.createStatement();
            java.sql.ResultSet rs=st.executeQuery(sql);
            while(rs.next()){
                Bean_website web=new Bean_website();
                web.setWeb_name(rs.getString(1));
                web.setCity(rs.getString(2));
                web.setAddress(rs.getString(3));
                web.setPhone_num(rs.getString(4));
                result.add(web);
            }

            rs.close();
            st.close();

        } catch (SQLException e) {
            e.printStackTrace();
            throw new DbException(e);
        }
        finally{
            if(conn!=null)
                try {
                    conn.close();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
        }
        return result;
    }

    public void createWeb(Bean_website web)throws BaseException{
        if(web.getWeb_name() == null || "".equals(web.getWeb_name())) throw new BusinessException("网点名字不能为空");
        if(web.getCity() == null || "".equals(web.getCity())) throw new BusinessException("网点所属城市不能为空");
        if(web.getAddress() == null || "".equals(web.getAddress())) throw new BusinessException("网点地址不能为空");
        if(web.getPhone_num() == null || "".equals(web.getPhone_num())) throw new BusinessException("网点联系电话不能为空");

        Connection conn=null;
        try {
            conn=DBUtil.getConnection();
            String sql="select * from website where web_name = ?";
            java.sql.PreparedStatement pst=conn.prepareStatement(sql);
            pst.setString(1,web.getWeb_name());
            java.sql.ResultSet rs=pst.executeQuery();
            if(rs.next()) throw new BusinessException("该网点已经存在");
            rs.close();
            pst.close();
            sql="insert into website(web_name, city, address, phone_num) values(?, ?, ?, ?)";
            pst=conn.prepareStatement(sql);
            pst.setString(1, web.getWeb_name());
            pst.setString(2, web.getCity());
            pst.setString(3,web.getAddress());
            pst.setString(4, web.getPhone_num());
            pst.execute();
            pst.close();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new DbException(e);
        }
        finally{
            if(conn!=null)
                try {
                    conn.close();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
        }
    }

    public void deleteWeb(String WebName)throws BaseException{
        Connection conn=null;
        try {
            conn=DBUtil.getConnection();
            String sql="select *\n" +
                    "from website\n" +
                    "where web_name = ?";
            java.sql.PreparedStatement pst=conn.prepareStatement(sql);
            pst.setString(1, WebName);
            java.sql.ResultSet rs=pst.executeQuery();
            if(!rs.next()) throw new BusinessException("该网点不存在");
            rs.close();
            pst.close();
            sql = "delete from website where web_name = ?";
            pst = conn.prepareStatement(sql);
            pst.setString(1, WebName);
            pst.execute();
            pst.close();

        } catch (SQLException e) {
            e.printStackTrace();
            throw new DbException(e);
        }
        finally{
            if(conn!=null)
                try {
                    conn.close();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
        }
    }
    public void modifyWebSite(Bean_website web)throws BaseException{
        if(web.getWeb_name() == null || "".equals(web.getWeb_name())) throw new BusinessException("网点名字不能为空");
        if(web.getCity() == null || "".equals(web.getCity())) throw new BusinessException("网点所属城市不能为空");
        if(web.getAddress() == null || "".equals(web.getAddress())) throw new BusinessException("网点地址不能为空");
        if(web.getPhone_num() == null || "".equals(web.getPhone_num())) throw new BusinessException("网点联系电话不能为空");

        Connection conn=null;
        try {
            conn=DBUtil.getConnection();
            String sql="update  website set city = ?, address = ?, phone_num = ? where web_name = ?";
            java.sql.PreparedStatement pst=conn.prepareStatement(sql);
            pst.setString(1,web.getCity());
            pst.setString(2, web.getAddress());
            pst.setString(3, web.getPhone_num());
            pst.setString(4, web.getWeb_name());


            pst.execute();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new DbException(e);
        }
        finally{
            if(conn!=null)
                try {
                    conn.close();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
        }

    }

}
