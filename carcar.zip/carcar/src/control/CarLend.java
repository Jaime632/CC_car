package control;

import model.Bean_car_info;
import model.Bean_car_ord;
import util.BaseException;
import util.BusinessException;
import util.DBUtil;
import util.DbException;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Bean_customer;

public class CarLend {
    public List<Bean_car_info> loadAllCar() throws BaseException {
        List<Bean_car_info> result=new ArrayList<Bean_car_info>();
        Connection conn=null;
        try {
            conn= DBUtil.getConnection();
            String sql="select car_id, model_name, web_name, plate_num, car_model, staus, price_day\n" +
                    "from car_info\n" +
                    "order by car_id";
            java.sql.Statement st=conn.createStatement();
            java.sql.ResultSet rs=st.executeQuery(sql);
            while(rs.next()){
                Bean_car_info car=new Bean_car_info();
                car.setPlate_num(rs.getString(1));
                car.setModel_name(rs.getString(2));
                car.setWeb_name(rs.getString(3));
                car.setPlate_num(rs.getString(4));
                car.setCar_model(rs.getString(5));
                car.setStaus(rs.getString(6));
                car.setPrice_day(rs.getInt(7));
                result.add(car);
            }
            rs.close();
            st.close();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new DbException(e);
        }
        finally{
            if(conn!=null)
                try {
                    conn.close();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
        }
        return result;
    }

    public void LendCar(Bean_car_info cord)throws BaseException{
        Connection conn=null;
        String aa = "订单进行中";
        String a2 = "已租赁";
        try {
            conn=DBUtil.getConnection();

//
//            String sql="select * from car_info where plate_num = ?";
//            java.sql.PreparedStatement pst=conn.prepareStatement(sql);
//            pst.setString(1, cord.getPlate_num());
//            java.sql.ResultSet rs=pst.executeQuery();
//            if(rs.next()) throw new BusinessException("该车已被租赁");
//            rs.close();
//            pst.close();


            String sql="insert into car_ord (customer_id, car_plate, in_time, all_time ,status, len_web ,spend_money) values(?, ?, ?, ?, ?, ?, ?)";
            java.sql.PreparedStatement pst=conn.prepareStatement(sql);

            pst.setString(1, cord.getCustomer_id());
            pst.setString(2, cord.getPlate_num());
            pst.setTimestamp(3, (new java.sql.Timestamp(System.currentTimeMillis())));
            pst.setInt(4, cord.getAll_time());
            pst.setString(5, aa);
            pst.setString(6, cord.getLen_web());

            String sb = "123";
            String str = sb.substring(2);
//            System.out.println(str);
            pst.setInt(7, 200);

//            cord.getPrice_day())*(cord.getAll_time())
            pst.execute();
            pst.close();

            sql = "update car_info set staus = ? where plate_num = ?";
            pst=conn.prepareStatement(sql);
            pst.setString(1, a2);
            pst.setString(2, cord.getPlate_num());
            pst.execute();
            pst.close();


        } catch (SQLException e) {
            e.printStackTrace();
            throw new DbException(e);
        }
        finally{
            if(conn!=null)
                try {
                    conn.close();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
        }
    }


    public void RenCar(Bean_car_ord cord)throws BaseException{
        Connection conn=null;
        String bb = "订单完成";
        String b2 = "未租赁";
        try {
            conn=DBUtil.getConnection();
            String sql="update car_ord set out_time = ? , status = ?, ren_web = ? where car_plate = ?";
            java.sql.PreparedStatement pst=conn.prepareStatement(sql);
            pst.setTimestamp(1, (new java.sql.Timestamp(System.currentTimeMillis())));
            pst.setString(2, bb);
            pst.setString(3, cord.getRen_web());
            pst.setString(4, cord.getCar_plate());

            pst.execute();
            pst.close();

            sql = "update car_info set web_name = ? , staus = ? where plate_num = ?";
            pst=conn.prepareStatement(sql);
            pst.setString(1, cord.getRen_web());
            pst.setString(2, b2);
            pst.setString(3, cord.getCar_plate());
            pst.execute();
            pst.close();

            if(cord.getLen_web() != cord.getRen_web())
            {
//                System.out.println(cord.getLen_web()+"  "+cord.getRen_web());
                sql = "insert into car_manage (car_plate, manage_time , len_web_name ,ren_web_name) values(?, ?, ?, ?)";
                pst = conn.prepareStatement(sql);
                pst.setString(1, cord.getCar_plate());
                pst.setTimestamp(2, (new java.sql.Timestamp(System.currentTimeMillis())));
                pst.setString(3, cord.getLen_web());
                pst.setString(4, cord.getRen_web());
                pst.execute();
                pst.close();

            }


        } catch (SQLException e) {
            e.printStackTrace();
            throw new DbException(e);
        }
        finally{
            if(conn!=null)
                try {
                    conn.close();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
        }
    }


}
