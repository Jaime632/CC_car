package control;
import model.Bean_car_ord;
import model.Bean_customer;
import model.Bean_user_manage;
import util.BaseException;
import util.BusinessException;
import util.DBUtil;
import util.DbException;

import javax.swing.plaf.synth.SynthEditorPaneUI;
import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Date;
import java.text.SimpleDateFormat;

public class UserManager{

        public static Bean_user_manage currentUser = null;
//    public static Bean_car_ord currentUser2;
//    private static Bean_customer currentUser2;
        public void createUser(Bean_user_manage user)throws BaseException{
            if(user.getUser_id() == null || "".equals((user.getUser_id()))) throw new BusinessException("账号不能为空");
            Connection conn=null;
            try {
                conn=DBUtil.getConnection();
                String sql="select * from user_manage where user_id=?";
                java.sql.PreparedStatement pst=conn.prepareStatement(sql);
                pst.setString(1,user.getUser_id());
                java.sql.ResultSet rs=pst.executeQuery();
                if(rs.next()) throw new BusinessException("登陆账号已经存在");
                rs.close();
                pst.close();
                sql="insert into user_manage(user_id,user_pwd,user_type) values(?,?,?)";
                pst=conn.prepareStatement(sql);
                pst.setString(1, user.getUser_id());
                user.setUser_pwd(user.getUser_id());//默认密码为账号
                pst.setString(2,user.getUser_pwd());
                pst.setString(3, user.getUser_type());
                pst.execute();
                pst.close();

            } catch (SQLException e) {
                e.printStackTrace();
                throw new DbException(e);
            }
            finally{
                if(conn!=null)
                    try {
                        conn.close();
                    } catch (SQLException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
            }
        }
        public List<Bean_user_manage> loadAllUsers(boolean withDeletedUser)throws BaseException{
            List<Bean_user_manage> result=new ArrayList<Bean_user_manage>();
            Connection conn=null;
            try {
                conn=DBUtil.getConnection();
                String sql="select user_id, user_pwd, user_type from user_manage";
                java.sql.Statement st=conn.createStatement();
                java.sql.ResultSet rs=st.executeQuery(sql);
                while(rs.next()){
                    Bean_user_manage u = new Bean_user_manage();
                    u.setUser_id(rs.getString(1));
                    u.setUser_pwd(rs.getString(2));
                    u.setUser_type(rs.getString(3));
                    result.add(u);
                }

                rs.close();
                st.close();

            } catch (SQLException e) {
                e.printStackTrace();
                throw new DbException(e);
            }
            finally{
                if(conn!=null)
                    try {
                        conn.close();
                    } catch (SQLException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
            }
            return result;
        }

        public void resetUserPwd(String userid)throws BaseException{
            Connection conn=null;
            try {
                conn=DBUtil.getConnection();
                String sql="select * from user_manage where user_id=?";
                java.sql.PreparedStatement pst=conn.prepareStatement(sql);
                pst.setString(1,userid);
                java.sql.ResultSet rs=pst.executeQuery();
                if(!rs.next()) throw new BusinessException("登陆账号不存在");
                rs.close();
                pst.close();
                sql="update user_manage set user_pwd=? where user_id=?";
                pst=conn.prepareStatement(sql);
                pst.setString(1, userid);
                pst.setString(2, userid);
                pst.execute();
                pst.close();
            } catch (SQLException e) {
                e.printStackTrace();
                throw new DbException(e);
            }
            finally{
                if(conn!=null)
                    try {
                        conn.close();
                    } catch (SQLException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
            }
        }
        public void deleteUser(String userid)throws BaseException{
            Connection conn=null;
            String a = "已删除";
            try {
                conn=DBUtil.getConnection();
                String sql="select * from user_manage where user_id=?";
                java.sql.PreparedStatement pst=conn.prepareStatement(sql);
                pst.setString(1,userid);
                java.sql.ResultSet rs=pst.executeQuery();
                if(!rs.next()) throw new BusinessException("登陆账号不存在");
                if(rs.getString(1) == "a") throw new BusinessException("该账号已经被删除");
                rs.close();
                pst.close();
                sql="update user_manage set user_type=? where user_id=?";
                pst=conn.prepareStatement(sql);
                pst.setString(1, a);
                pst.setString(2, userid);
                pst.execute();
                pst.close();
            } catch (SQLException e) {
                e.printStackTrace();
                throw new DbException(e);
            }
            finally{
                if(conn!=null)
                    try {
                        conn.close();
                    } catch (SQLException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
            }
        }
        public Bean_user_manage loadUser(String userid)throws BaseException{
            Connection conn=null;
            String b = "已删除";
            try {
                conn=DBUtil.getConnection();
                String sql="select * from user_manage where user_id=?";
                java.sql.PreparedStatement pst=conn.prepareStatement(sql);
                pst.setString(1,userid);
                java.sql.ResultSet rs=pst.executeQuery();
                if(!rs.next()) throw new BusinessException("登陆账号不存在");
                Bean_user_manage u=new Bean_user_manage();
                u.setUser_id(rs.getString(1));
                u.setUser_pwd(rs.getString(2));
                u.setUser_type(rs.getString(3));
                if(u.getUser_type()==b) throw new BusinessException("该账号已经被删除");
                rs.close();
                pst.close();
                return u;
            } catch (SQLException e) {
                e.printStackTrace();
                throw new DbException(e);
            }
            finally{
                if(conn!=null)
                    try {
                        conn.close();
                    } catch (SQLException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
            }

        }

    public void changeUser(Bean_user_manage us) throws BusinessException, DbException {
        if(us.getUser_pwd()==null || "".equals(us.getUser_pwd())) throw new BusinessException("新密码不能为空");

        Connection conn=null;
        try {
            conn=DBUtil.getConnection();
            String sql="update user_manage set user_pwd=? where user_id=?";
            java.sql.PreparedStatement pst=conn.prepareStatement(sql);
            pst.setString(1, us.getUser_pwd());
            pst.setString(2, us.getUser_id());
            pst.execute();
            pst.close();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new DbException(e);
        }
        finally{
            if(conn!=null)
                try {
                    conn.close();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
        }
    }
    public void createUser2(Bean_customer user)throws BaseException{
        if(user.getCustomer_id() == null || "".equals((user.getCustomer_id()))) throw new BusinessException("账号不能为空");
        if(user.getPassWord() == null || "".equals((user.getPassWord()))) throw new BusinessException("密码不能为空");
        if(user.getCity() == null || "".equals((user.getCity()))) throw new BusinessException("所在城市不能为空");
        if(user.getMailbox() == null || "".equals((user.getMailbox()))) throw new BusinessException("邮箱不能为空");
        if(user.getPhone_number()== null || "".equals((user.getPhone_number()))) throw new BusinessException("电话不能为空");
        if(user.getSex() == null || "".equals((user.getSex()))) throw new BusinessException("性别不能为空");

        Connection conn=null;
        try {
            conn=DBUtil.getConnection();
            String sql="select * from customer where customer_id=?";
            java.sql.PreparedStatement pst=conn.prepareStatement(sql);
            pst.setString(1,user.getCustomer_id());
            java.sql.ResultSet rs=pst.executeQuery();
            if(rs.next()) throw new BusinessException("用户名已经存在");
            rs.close();
            pst.close();

            sql="insert into customer (customer_id, sex, password, phone_number, mailbox, city, regtime) values(?,?,?,?,?,?,?)";
            pst=conn.prepareStatement(sql);
            pst.setString(1, user.getCustomer_id());
            pst.setString(2, user.getSex());
            pst.setString(3, user.getPassWord());
            pst.setString(4, user.getPhone_number());
            pst.setString(5, user.getMailbox());
            pst.setString(6, user.getCity());
            pst.setTimestamp(7, (new java.sql.Timestamp(System.currentTimeMillis())));
            pst.execute();
            pst.close();

            String aa = "用户";
            sql = "insert into user_manage (user_id, user_pwd, user_type) value (?,?,?)";
            pst = conn.prepareStatement(sql);
            pst.setString(1, user.getCustomer_id());
            pst.setString(2, user.getPassWord());
            pst.setString(3, aa);
            pst.execute();
            pst.close();

        } catch (SQLException e) {
            e.printStackTrace();
            throw new DbException(e);
        }
        finally{
            if(conn!=null)
                try {
                    conn.close();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
        }
    }


    public void ModifyPerson(Bean_customer cu) throws BusinessException, DbException {
        if(cu.getCustomer_id() == null || "".equals((cu.getCustomer_id()))) throw new BusinessException("账号不能为空");
        if(cu.getPassWord() == null || "".equals((cu.getPassWord()))) throw new BusinessException("密码不能为空");
        if(cu.getCity() == null || "".equals((cu.getCity()))) throw new BusinessException("所在城市不能为空");
        if(cu.getMailbox() == null || "".equals((cu.getMailbox()))) throw new BusinessException("邮箱不能为空");
        if(cu.getPhone_number()== null || "".equals((cu.getPhone_number()))) throw new BusinessException("电话不能为空");
        if(cu.getSex() == null || "".equals((cu.getSex()))) throw new BusinessException("性别不能为空");

        Connection conn=null;
        try {
            conn=DBUtil.getConnection();
            String sql="update customer set sex = ?,password = ?, phone_number =?, mailbox = ?, city = ? , regtime = ? where customer_id = ?";
            java.sql.PreparedStatement pst=conn.prepareStatement(sql);
            pst.setString(1, cu.getSex());
            pst.setString(2, cu.getPassWord());
            pst.setString(3, cu.getPhone_number());
            pst.setString(4, cu.getMailbox());
            pst.setString(5, cu.getCity());
            pst.setTimestamp(6, (new java.sql.Timestamp(System.currentTimeMillis())));
            pst.setString(7, cu.getCustomer_id());
            pst.execute();
            pst.close();

            sql = "update user_manage set user_pwd = ? where user_id = ?";
            pst = conn.prepareStatement(sql);
            pst.setString(1, cu.getPassWord());
            pst.setString(2, cu.getCustomer_id());

        } catch (SQLException e) {
            e.printStackTrace();
            throw new DbException(e);
        }
        finally{
            if(conn!=null)
                try {
                    conn.close();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
        }
    }




}
