package control;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Bean_car_model_info;
import util.BaseException;
import util.BusinessException;
import util.DBUtil;
import util.DbException;

public class CarModel {

    public List<Bean_car_model_info>  loadAllCarModel() throws BaseException{
        List<Bean_car_model_info> result=new ArrayList<Bean_car_model_info>();
        Connection conn=null;
        try {   
            conn=DBUtil.getConnection();
            String sql="select model_name, brand, displacement, gear, seat_number, price\n" +
                    "from car_model_info\n" +
                    "order by model_name";
            java.sql.Statement st=conn.createStatement();
            java.sql.ResultSet rs=st.executeQuery(sql);
            while(rs.next()){
                Bean_car_model_info model=new Bean_car_model_info();
                model.setModel_name(rs.getString(1));
                model.setBrand(rs.getString(2));
                model.setDisplacement(rs.getString(3));
                model.setGear(rs.getString(4));
                model.setSeat_number(rs.getString(5));
                model.setPrice(rs.getDouble(6));
                result.add(model);
            }

            rs.close();
            st.close();

        } catch (SQLException e) {
            e.printStackTrace();
            throw new DbException(e);
        }
        finally{
            if(conn!=null)
                try {
                    conn.close();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
        }
        return result;
    }

    public void createModel(Bean_car_model_info model)throws BaseException{

        if(model.getModel_name() == null || "".equals(model.getModel_name())) throw new BusinessException("车型名字不能为空");
        if(model.getBrand() == null || "".equals(model.getBrand())) throw new BusinessException("品牌不能为空");
        if(model.getDisplacement() == null || "".equals(model.getDisplacement())) throw new BusinessException("排量不能为空");
        if(model.getGear() == null || "".equals(model.getGear())) throw new BusinessException("排挡不能为空");
        if("".equals((model.getSeat_number()+""))) throw new BusinessException("座位数不能为空");
        if("".equals((model.getPrice()+""))) throw new BusinessException("价格不能为空");


        Connection conn=null;
        try {
            conn=DBUtil.getConnection();

            String sql="select * from car_model_info where model_name = ?";
            java.sql.PreparedStatement pst=conn.prepareStatement(sql);
            pst.setString(1,model.getModel_name());
            java.sql.ResultSet rs=pst.executeQuery();
            if(rs.next()) throw new BusinessException("该车型已经存在");
            rs.close();
            pst.close();

            sql="insert into car_model_info(model_name, brand, displacement, gear, seat_number, price) values(?, ?, ?, ?, ?, ?)";
            pst=conn.prepareStatement(sql);
            pst.setString(1, model.getModel_name());
            pst.setString(2, model.getBrand());
            pst.setString(3, model.getDisplacement());
            pst.setString(4, model.getGear());
            pst.setString(5, model.getSeat_number());
            pst.setDouble(6, model.getPrice());
            pst.execute();
            pst.close();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new DbException(e);
        }
        finally{
            if(conn!=null)
                try {
                    conn.close();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
        }
    }

    public void deleteModel(String ModelName)throws BaseException{
        Connection conn=null;
        try {
            conn=DBUtil.getConnection();
            String sql="select *\n" +
                    "from car_model_info\n" +
                    "where model_name = ?";
            java.sql.PreparedStatement pst=conn.prepareStatement(sql);
            pst.setString(1,ModelName);
            java.sql.ResultSet rs=pst.executeQuery();
            if(!rs.next()) throw new BusinessException("该车类不存在");
            rs.close();
            pst.close();
            sql = "delete from car_model_info where model_name = ?";
            pst = conn.prepareStatement(sql);
            pst.setString(1, ModelName);
            pst.execute();
            pst.close();

        } catch (SQLException e) {
            e.printStackTrace();
            throw new DbException(e);
        }
        finally{
            if(conn!=null)
                try {
                    conn.close();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
        }
    }

    public void modifyCarModel(Bean_car_model_info model)throws BaseException{
        if(model.getModel_name() == null || "".equals(model.getModel_name())) throw new BusinessException("车型名字不能为空");
        if(model.getBrand() == null || "".equals(model.getBrand())) throw new BusinessException("品牌不能为空");
        if(model.getDisplacement() == null || "".equals(model.getDisplacement())) throw new BusinessException("排量不能为空");
        if(model.getGear() == null || "".equals(model.getGear())) throw new BusinessException("排挡不能为空");
        if("".equals((model.getSeat_number()+""))) throw new BusinessException("座位数不能为空");
        if("".equals((model.getPrice()+""))) throw new BusinessException("价格不能为空");

        Connection conn=null;
        try {
            conn=DBUtil.getConnection();
            String sql="update car_model_info set brand=?, displacement=?, gear=?, seat_number=?, price=? where model_name = ?";
            java.sql.PreparedStatement pst=conn.prepareStatement(sql);
            pst.setString(6, model.getModel_name());
            pst.setString(1, model.getBrand());
            pst.setString(2, model.getDisplacement());
            pst.setString(3, model.getGear());
            pst.setString(4, model.getSeat_number());
            pst.setDouble(5, model.getPrice());
            pst.execute();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new DbException(e);
        }
        finally{
            if(conn!=null)
                try {
                    conn.close();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
        }

    }
}