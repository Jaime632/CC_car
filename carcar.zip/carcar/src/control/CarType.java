package control;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Bean_car_type;
import model.Bean_user_manage;
import util.BaseException;
import util.BusinessException;
import util.DBUtil;
import util.DbException;
import java.math.BigInteger;

public class CarType {
    public List<Bean_car_type>  loadAllCarType() throws BaseException{
        List<Bean_car_type> result=new ArrayList<Bean_car_type>();
        Connection conn=null;
        try {
            conn=DBUtil.getConnection();
            String sql="select type_name,type_des\n" +
                    "from car_type\n" +
                    "order by type_name";
            java.sql.Statement st=conn.createStatement();
            java.sql.ResultSet rs=st.executeQuery(sql);
            while(rs.next()){
                Bean_car_type type=new Bean_car_type();
                type.setType_name(rs.getString(1));
                type.setType_des(rs.getString(2));
                result.add(type);
            }
            rs.close();
            st.close();

        } catch (SQLException e) {
            e.printStackTrace();
            throw new DbException(e);
        }
        finally{
            if(conn!=null)
                try {
                    conn.close();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
        }
        return result;
    }

    public void createType(Bean_car_type type)throws BaseException{
        if("".equals((type.getType_name()+""))) throw new BusinessException("车类编号不能为空");
        if(type.getType_name() == null || "".equals(type.getType_name())) throw new BusinessException("车类名字不能为空");
        Connection conn=null;
        try {
            conn=DBUtil.getConnection();
            String sql="select * from car_type where type_name=?";
            java.sql.PreparedStatement pst=conn.prepareStatement(sql);
            pst.setString(1, type.getType_name());
            java.sql.ResultSet rs=pst.executeQuery();
            if(rs.next()) throw new BusinessException("车类已经存在");
            rs.close();
            pst.close();

            sql="insert into car_type(type_name, type_des) values(?, ?)";
            pst=conn.prepareStatement(sql);
            pst.setString(1, type.getType_name());
            pst.setString(2, type.getType_des());
            pst.execute();
            pst.close();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new DbException(e);
        }
        finally{
            if(conn!=null)
                try {
                    conn.close();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
        }
    }

    public void deleteType(String type_name)throws BaseException{
        Connection conn=null;
        try {
            conn=DBUtil.getConnection();
            String sql="select *\n" +
                    "from car_type\n" +
                    "where type_name = ?";
            java.sql.PreparedStatement pst=conn.prepareStatement(sql);
            pst.setString(1,type_name);
            java.sql.ResultSet rs=pst.executeQuery();
            if(!rs.next()) throw new BusinessException("该车类不存在");
            rs.close();
            pst.close();
//            sql = "select car"

            sql = "delete from car_type where type_name = ?";
            pst = conn.prepareStatement(sql);
            pst.setString(1, type_name);
            pst.execute();
            pst.close();

        } catch (SQLException e) {
            e.printStackTrace();
            throw new DbException(e);
        }
        finally{
            if(conn!=null)
                try {
                    conn.close();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
        }
    }

    public void modifyCarType(Bean_car_type type)throws BaseException{
        if(type.getType_name() == null || "".equals(type.getType_name())) throw new BusinessException("车类名字不能为空");

        Connection conn=null;
        try {
            conn=DBUtil.getConnection();
            String sql="update car_type set type_des = ? where type_name= ?";
            java.sql.PreparedStatement pst=conn.prepareStatement(sql);
            pst.setString(1, type.getType_des());
            pst.setString(2, type.getType_name());
            pst.execute();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new DbException(e);
        }
        finally{
            if(conn!=null)
                try {
                    conn.close();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
        }

    }
}
